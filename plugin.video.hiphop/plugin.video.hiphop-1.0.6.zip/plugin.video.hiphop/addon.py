#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmc,xbmcgui,xbmcaddon,xbmcplugin,os,sys,urllib

def __fix_encoding__(path):
	if sys.version_info.major == 2:

		if sys.platform.startswith('win'):return path.decode('utf-8')
		else:return path.decode('utf-8').encode('ISO-8859-1')

	elif sys.version_info.major == 3:return path

__addon__ =  xbmcaddon.Addon()
__addon_path__ = __fix_encoding__(__addon__.getAddonInfo('path'))


def __set_content__(content):
	xbmcplugin.setContent(int(sys.argv[1]),content)
	
def __set_view_mode__(view_mode):
    xbmc.executebuiltin('Container.SetViewMode(%s)' % (view_mode))
	
def __set_end_of_directory__(succeeded=True,updateListing=False,cacheToDisc=False):
	xbmcplugin.endOfDirectory(handle=int(sys.argv[1]),succeeded=True,updateListing=False,cacheToDisc=False)
	
def __get_youtube_live_stream__(channel_id):
	return'plugin://plugin.video.youtube/play/?channel_id=%s&live=1' % channel_id

def __get_youtube_video__(video_id):
	return'plugin://plugin.video.youtube/?action=play_video&videoid=%s' % video_id

def __get_youtube_playlist__(playlist_id):
	return'plugin://plugin.video.youtube/playlist/%s/' % playlist_id

def __get_youtube_channel__(channel_id):
	return'plugin://plugin.video.youtube/channel/%s/' % channel_id

def __get_youtube_search__(search_text):
	return'plugin://plugin.video.youtube/search/?q=%s' % search_text

def __get_youtube_user__(user_id):
	return'plugin://plugin.video.youtube/user/%s/' % user_id

def __add_item__(title,url,icon,plot,is_folder=False):
	item=xbmcgui.ListItem(title,iconImage=icon,thumbnailImage=icon)
	item.setInfo(type='Video',infoLabels={'Title':title,'Plot':plot} )
	item.setProperty('IsPlayable','true')
	xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=item,isFolder=is_folder)

def __add_dir__(title,url,icon,plot,mode,is_folder=True):
	url=sys.argv[0]+'?title='+urllib.quote_plus(title)+'&url='+urllib.quote_plus(url)+'&Image='+urllib.quote_plus(icon)+'&mode='+str(mode)
	item=xbmcgui.ListItem(title,iconImage=icon,thumbnailImage=icon)
	item.setInfo( type='Video', infoLabels={'Title':title ,'Plot':plot})
	xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=item,isFolder=is_folder)
    
def __get_params__():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?', '')
        if params[len(params) - 1] == '/':
            params = params[0:len(params) - 2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if len(splitparams) == 2:
                param[splitparams[0]] = splitparams[1]

        return param
params = __get_params__()

title = None
try:title = urllib.unquote_plus(params['title'])
except:pass

url = None
try:url = urllib.unquote_plus(params['url'])
except:pass

image = None
try:image = urllib.unquote_plus(params['image'])
except:pass

mode = None
try:mode = int(params['mode'])
except:pass


if mode == None:
  __add_dir__('Deutscher Hip Hop','',os.path.join(__addon_path__,'resources','Deutscher Hip Hop icons','Deutscher Hip Hop.png'),'[B][COLOR red]Deutscher Hip Hop Channel[/B][/COLOR]',1)
  __add_dir__('Deutschrap Update','',os.path.join(__addon_path__,'resources','Deutscher Hip Hop icons','Deutschrap-Update.png'),'[B][COLOR red]Deutschrap-Update[/B][/COLOR]',2)
  #__add_dir__('Test 3','',os.path.join(__addon_path__,'resources','icons','test.jpg'),'DEINE INFO - PLOT ?',3)

elif mode == 1:
    __add_item__('BangerChannel',__get_youtube_channel__('UCbDNCzgdLlvYY9dk5M8063A'),os.path.join(__addon_path__,'resources','icons','BangerChannel.jpg'),'Plot ?',is_folder=True)
    __add_item__('ALPHA MUSIC EMPIRE',__get_youtube_channel__('UCzmO7GegLke-jb5uZSQ9_HA'),os.path.join(__addon_path__,'resources','icons','ALPHA MUSIC EMPIRE.jpg'),'Plot ?',is_folder=True)
    __add_item__('Sido',__get_youtube_user__('officialsidomusik'),os.path.join(__addon_path__,'resources','icons','Sido.jpg'),'Plot ?',is_folder=True)
    __add_item__('Kool Savas',__get_youtube_user__('EssahTV'),os.path.join(__addon_path__,'resources','icons','Kool Savas.jpg'),'Plot ?',is_folder=True)
    __add_item__('CrhymeTV',__get_youtube_channel__('UCGh8tmH9x9njaI2mXfh2fyg'),os.path.join(__addon_path__,'resources','icons','CrhymeTV.jpg'),'Plot ?',is_folder=True)
    __add_item__('Luciano',__get_youtube_channel__('UCVWm9bTQLmMwHI0To5zQFGA'),os.path.join(__addon_path__,'resources','icons','luciano.jpg'),'Plot ?',is_folder=True)
    __add_item__('Kollegah',__get_youtube_channel__('UCLmyWpIwbKr6HJQ_teYCkVw'),os.path.join(__addon_path__,'resources','icons','Kollegah.jpg'),'Plot ?',is_folder=True)
    __add_item__('Capital Bra',__get_youtube_channel__('UCeJIbOka3ZF8TSWT_-kHmSA'),os.path.join(__addon_path__,'resources','icons','Capital Bra.jpg'),'Plot ?',is_folder=True)
    __add_item__('Bausa',__get_youtube_channel__('UCJl-cGDSoGlB86vB_3scwAQ'),os.path.join(__addon_path__,'resources','icons','Bausashaus.jpg'),'Plot ?',is_folder=True)
    __add_item__('Kontra K',__get_youtube_channel__('UCIgCb1dYprH140Ds0mgeAUA'),os.path.join(__addon_path__,'resources','icons','Kontra K.jpg'),'Plot ?',is_folder=True)
    __add_item__('Stay High Ufo361',__get_youtube_channel__('UCXK2490SNd8EOm84Es6USjw'),os.path.join(__addon_path__,'resources','icons','Stay High.jpg'),'Plot ?',is_folder=True)
    __add_item__('SLS MUSIC',__get_youtube_channel__('UCxIc_NmsGMv4AsTo-mV4Hdg'),os.path.join(__addon_path__,'resources','icons','SLS MUSIC.jpg'),'Plot ?',is_folder=True)
    __add_item__('Massiv',__get_youtube_channel__('UCejUnAtmIGNyh4byycOI-Ww'),os.path.join(__addon_path__,'resources','icons','Massiv.jpg'),'Plot ?',is_folder=True)
    __add_item__('Selfmade Records',__get_youtube_channel__('UCDzpxJB1oNEg7a2Np14TEMQ'),os.path.join(__addon_path__,'resources','icons','Selfmade Records.jpg'),'Plot ?',is_folder=True)
    __add_item__('385idéal',__get_youtube_channel__('UCvnCXuh_zhm75EJ89qJ95Kw'),os.path.join(__addon_path__,'resources','icons','385ideal.jpg'),'Plot ?',is_folder=True)
    __add_item__('KC Rebell',__get_youtube_channel__('UCjdfpszupX-_8TNvVTyoD-Q'),os.path.join(__addon_path__,'resources','icons','KC Rebell.jpg'),'Plot ?',is_folder=True)
    __add_item__('SoulForce Records',__get_youtube_channel__('UCzVu1R27dBESV7ewkkeCpXg'),os.path.join(__addon_path__,'resources','icons','SoulForce Records.jpg'),'Plot ?',is_folder=True)
    __add_item__('Azzlackz',__get_youtube_channel__('UCnH4k3ASwytYAgfsW83OvTg'),os.path.join(__addon_path__,'resources','icons','Azzlackz.jpg'),'Plot ?',is_folder=True)
    __add_item__('Milonair TV',__get_youtube_channel__('UCTJnlbVh-5ONLDbyOOA-fVw'),os.path.join(__addon_path__,'resources','icons','Milonair TV.jpg'),'Plot ?',is_folder=True)
    __add_item__('WORLD WIDE RAP[',__get_youtube_channel__('UCy2i0-VfEbcnv-8-CyF8axw'),os.path.join(__addon_path__,'resources','icons','WORLD WIDE RAP.jpg'),'Plot ?',is_folder=True)
    __add_item__('TEAM KUKU',__get_youtube_channel__('UCGU9EqK5V5m141sNPCOfRBg'),os.path.join(__addon_path__,'resources','icons','TEAM KUKU.jpg'),'Plot ?',is_folder=True)
    __add_item__('Fard',__get_youtube_channel__('UCU920m2cTElVE62gZ84iqrQ'),os.path.join(__addon_path__,'resources','icons','Fard.jpg'),'Plot ?',is_folder=True)
    __add_item__('Manuellsen',__get_youtube_channel__('UCTDTPAm7hgy25Xklg9Yf7eQ'),os.path.join(__addon_path__,'resources','icons','Manuellsen.jpg'),'Plot ?',is_folder=True)
    __add_item__('AK AUSSERKONTROLLE',__get_youtube_channel__('UCNNerW9VaDLNaoT-QO_rRgw'),os.path.join(__addon_path__,'resources','icons','AK AUSSERKONTROLLE.jpg'),'Plot ?',is_folder=True)
    __add_item__('LifeisPainTv',__get_youtube_channel__('UCAbiUl42boUt6vUL019r9Bw'),os.path.join(__addon_path__,'resources','icons','LifeisPainTv.jpg'),'Plot ?',is_folder=True)
    __add_item__('Life Is Battle Area',__get_youtube_channel__('UCzPE_f8K8RzpG9nemUkQEsQ'),os.path.join(__addon_path__,'resources','icons','Life Is Battle Area.jpg'),'Plot ?',is_folder=True)
    __add_item__('RAF Camora',__get_youtube_channel__('UChqcJ_MhP9a4bXy1jQ0QPzQ'),os.path.join(__addon_path__,'resources','icons','RAF Camora.jpg'),'Plot ?',is_folder=True)
    __add_item__('Qualitäter Music',__get_youtube_channel__('UCL6QS1qyZ_nnB62dyZIAT7A'),os.path.join(__addon_path__,'resources','icons','Qualitater Music.jpg'),'Plot ?',is_folder=True)
    __add_item__('KOREE',__get_youtube_channel__('UCLyRHlyYSKZnyOunfBwfp5g'),os.path.join(__addon_path__,'resources','icons','KOREE.jpg'),'Plot ?',is_folder=True)
    __add_item__('FettC',__get_youtube_channel__('UC62xPDaMST7-AwerR_vxdmg'),os.path.join(__addon_path__,'resources','icons','FettC.jpg'),'Plot ?',is_folder=True)
    __add_item__('ALLES ODER NIX RECORDS',__get_youtube_channel__('UCqbKhBvxM3qWzC8huPiifYg'),os.path.join(__addon_path__,'resources','icons','ALLES ODER NIX RECORDS.jpg'),'Plot ?',is_folder=True)
    __add_item__('K.I.Z',__get_youtube_channel__('UCy9Nbtsu7QzefrNsT9nYkzQ'),os.path.join(__addon_path__,'resources','icons','kiz.jpg'),'Plot ?',is_folder=True)
    __add_item__('mosh36',__get_youtube_channel__('UChiDPcLh7uVeGXgkk3ik_ZA'),os.path.join(__addon_path__,'resources','icons','mosh36TV.jpg'),'Plot ?',is_folder=True)
    __add_item__('BUY OR DIE - RECORDS',__get_youtube_channel__('UCbiNa0pLPy2twNkyRzy9Aig'),os.path.join(__addon_path__,'resources','icons','BUY OR DIE - RECORDS.jpg'),'Plot ?',is_folder=True)
    __add_item__('Favorite',__get_youtube_channel__('UCYzGvEIKJ-pzX9XgKfDJGLw'),os.path.join(__addon_path__,'resources','icons','Favorite.jpg'),'Plot ?',is_folder=True)
    
elif mode == 2:
    __add_item__('Rap Check',__get_youtube_user__('GangstaRapLeopard'),os.path.join(__addon_path__,'resources','icons','Rap Check.jpg'),'Plot ?',is_folder=True)
    __add_item__('TV Strassensound',__get_youtube_user__('TVstrassensound'),os.path.join(__addon_path__,'resources','icons','TV Strassensound.jpg'),'Plot ?',is_folder=True)
    __add_item__('16BARS',__get_youtube_user__('www16barsde'),os.path.join(__addon_path__,'resources','icons','16BARS.jpg'),'Plot ?',is_folder=True)



#-------------------#
#__set_view_mode__('50')
__set_content__('movies')
__set_end_of_directory__()
