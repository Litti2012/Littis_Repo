#!/usr/bin/python
# -*- coding: utf-8 -*-
import rap,xbmc
import rap as libkids

list()

#####by Litti19928#####