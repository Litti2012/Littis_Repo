#!/usr/bin/python3
# -*- coding: utf-8 -*-
import os,sys,xbmc,xbmcgui,xbmcplugin,xbmcaddon,urllib

def __fix_encoding__(path):
	if sys.version_info.major == 2:

		if sys.platform.startswith('win'):return path.decode('utf-8')
		else:return path.decode('utf-8').encode('ISO-8859-1')

	elif sys.version_info.major == 3:return path

def __quote_plus__(s):
	if sys.version_info.major == 2:return urllib.quote_plus(s)
	elif sys.version_info.major == 3:return urllib.parse.quote_plus(s)
	
def __unquote_plus__(s):
	if sys.version_info.major == 2:return urllib.unquote_plus(s)
	elif sys.version_info.major == 3:return urllib.parse.unquote_plus(s)

__addon__ =  xbmcaddon.Addon()
__addon_path__ = __fix_encoding__(__addon__.getAddonInfo('path'))

sys.path.append(os.path.join(__addon_path__,'resources','lib'))
import cfscraper

def __set_content__(content):
	xbmcplugin.setContent(int(sys.argv[1]),content)

def __set_view_mode__(view_mode):
    xbmc.executebuiltin('Container.SetViewMode(%s)' % (view_mode))

def __end_of_directory__(succeeded=True,updateListing=False,cacheToDisc=False):
	xbmcplugin.endOfDirectory(handle=int(sys.argv[1]),succeeded=True,updateListing=False,cacheToDisc=False)

def __get_youtube_live_stream__(channel_id):
	return'plugin://plugin.video.youtube/play/?channel_id=%s&live=1' % channel_id

def __get_youtube_video__(video_id):
	return'plugin://plugin.video.youtube/?action=play_video&videoid=%s' % video_id

def __get_youtube_playlist__(playlist_id):
	return'plugin://plugin.video.youtube/playlist/%s/' % playlist_id

def __get_youtube_channel__(channel_id):
	return'plugin://plugin.video.youtube/channel/%s/' % channel_id

def __get_youtube_user__(user_id):
	return'plugin://plugin.video.youtube/user/%s/' % user_id

def __add_item__(title,url,img,plot,is_folder=False):
    listitem=xbmcgui.ListItem(label=title,path=url)
    listitem.setInfo('Video',infoLabels={'Title':title,'Plot':plot,} )
    listitem.setArt({'icon':img,'poster':img,'banner':img,})
    listitem.setProperty('IsPlayable','true')
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=listitem,isFolder=is_folder)

def __add_dir__(title,url,img,plot,mode,is_folder=True):
    url=sys.argv[0]+'?title='+__quote_plus__(title)+'&url='+__quote_plus__(url)+'&Image='+__quote_plus__(img)+'&mode='+str(mode)
    listitem=xbmcgui.ListItem(label=title,path=url)
    listitem.setInfo('Video',infoLabels={'Title':title,'Plot':plot} )
    listitem.setArt({'icon':img,'poster':img,'banner':img,})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=listitem,isFolder=is_folder)

def __get_params__():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?', '')
        if params[len(params) - 1] == '/':
            params = params[0:len(params) - 2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if len(splitparams) == 2:
                param[splitparams[0]] = splitparams[1]

        return param
params = __get_params__()

title = None
try:title = __unquote_plus__(params['title'])
except:pass

url = None
try:url = __unquote_plus__(params['url'])
except:pass

image = None
try:image = __unquote_plus__(params['image'])
except:pass

mode = None
try:mode = int(params['mode'])
except:pass

if mode == None:
  __add_dir__('Film Trailer','',os.path.join(__addon_path__,'resources','film trailer','Film Trailer.png'),'DEINE INFO - PLOT ?',1)
  __add_dir__('Serien Trailer','',os.path.join(__addon_path__,'resources','serien trailer','Serien Trailer.png'),'DEINE INFO - PLOT ?',2)
  #__add_dir__('Test 3','',os.path.join(__addon_path__,'resources','icons','test.jpg'),'DEINE INFO - PLOT ?',3)



elif mode == 1:
    __add_item__('Apple.TV',__get_youtube_channel__('UCMWc04n2YO39TRyi1I1o9pw'),os.path.join(__addon_path__,'resources','film trailer','Appel.tv.jpg'),'Plot ?',is_folder=True)
    __add_item__('Netflix',__get_youtube_user__('Netflixdach'),os.path.join(__addon_path__,'resources','film trailer','Netflix.jpg'),'Plot ?',is_folder=True)
    __add_item__('KinoCheck',__get_youtube_user__('KinoCheck'),os.path.join(__addon_path__,'resources','film trailer','KinoCheck.jpg'),'Plot ?',is_folder=True)
    __add_item__('KinoCheck Familie',__get_youtube_channel__('UC02ebHCrFJKxM4Achcl0tlw'),os.path.join(__addon_path__,'resources','film trailer','KinoCheck Familie.jpg'),'Plot ?',is_folder=True)
    __add_item__('KinoCheck Home',__get_youtube_channel__('UCV297SPE0sBWzmhmACKJP-w'),os.path.join(__addon_path__,'resources','film trailer','KinoCheck Home.jpg'),'Plot ?',is_folder=True)
    __add_item__('KinoStar',__get_youtube_user__('KinoStarDE'),os.path.join(__addon_path__,'resources','film trailer','KinoStarDE.jpg'),'Plot ?',is_folder=True)
    __add_item__('Moviepilot',__get_youtube_user__('moviepiloten'),os.path.join(__addon_path__,'resources','film trailer','Moviepilot.jpg'),'Plot ?',is_folder=True)
    __add_item__('Moviepilot Family',__get_youtube_user__('moviepilotKids'),os.path.join(__addon_path__,'resources','film trailer','Moviepilot Family.jpg'),'Plot ?',is_folder=True)
    __add_item__('Moviepilot Trailer',__get_youtube_user__('MoviepilotTrailer'),os.path.join(__addon_path__,'resources','film trailer','Moviepilot Trailer.jpg'),'Plot ?',is_folder=True)
    
    
elif mode ==2:
    __add_item__('SerienFlash',__get_youtube_user__('letstalkaboutserien'),os.path.join(__addon_path__,'resources','serien trailer','SerienFlash.jpg'),'Plot ?',is_folder=True)
    
#__set_view_mode__('50')
__set_content__('movies')
__end_of_directory__()
