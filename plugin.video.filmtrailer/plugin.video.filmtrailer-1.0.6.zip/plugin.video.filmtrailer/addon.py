#!/usr/bin/python3
# -*- coding: utf-8 -*-
import os,sys,xbmc,xbmcgui,xbmcplugin,xbmcaddon

def __fix_encoding__(path):
	if sys.version_info.major == 2:

		if sys.platform.startswith('win'):return path.decode('utf-8')
		else:return path.decode('utf-8').encode('ISO-8859-1')

	elif sys.version_info.major == 3:return path

__addon__ =  xbmcaddon.Addon()
__addon_path__ = __fix_encoding__(__addon__.getAddonInfo('path'))


def __set_content__(content):
	xbmcplugin.setContent(int(sys.argv[1]),content)

def __set_view_mode__(view_mode):
    xbmc.executebuiltin('Container.SetViewMode(%s)' % (view_mode))

def __set_end_of_directory__(succeeded=True,updateListing=False,cacheToDisc=False):
	xbmcplugin.endOfDirectory(handle=int(sys.argv[1]),succeeded=True,updateListing=False,cacheToDisc=False)

def __get_youtube_live_stream__(channel_id):
	return'plugin://plugin.video.youtube/play/?channel_id=%s&live=1' % channel_id

def __get_youtube_video__(video_id):
	return'plugin://plugin.video.youtube/?action=play_video&videoid=%s' % video_id

def __get_youtube_playlist__(playlist_id):
	return'plugin://plugin.video.youtube/playlist/%s/' % playlist_id

def __get_youtube_channel__(channel_id):
	return'plugin://plugin.video.youtube/channel/%s/' % channel_id

def __get_youtube_user__(user_id):
	return'plugin://plugin.video.youtube/user/%s/' % user_id

def __add_item__(title,url,icon,plot,is_folder=False):
	item=xbmcgui.ListItem(title,iconImage=icon,thumbnailImage=icon)
	item.setInfo(type='Video',infoLabels={'Title':title,'Plot':plot} )
	item.setProperty('IsPlayable','true')
	xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=item,isFolder=is_folder)

#-------------------#
#__set_view_mode__('50')
__set_content__('movies')
#-----------------------------------------------------------------------------------------------#
__add_item__('[B][COLOR red]Netflix[/B][/COLOR]',__get_youtube_user__('netflixdach'),os.path.join(__addon_path__,'resources','icons','Netflix.jpg'),'Plot ?',is_folder=True)
__add_item__('[B][COLOR skyblue]FILMSTARTSTV[/B][/COLOR]',__get_youtube_user__('FILMSTARTSTV'),os.path.join(__addon_path__,'resources','icons','FILMSTARTSTV.jpg'),'Plot ?',is_folder=True)
__add_item__('[B][COLOR red]KinoCheck[/B][/COLOR]',__get_youtube_channel__('UCOL10n-as9dXO2qtjjFUQbQ'),os.path.join(__addon_path__,'resources','icons','KinoCheck.jpg'),'Plot ?',is_folder=True)
__add_item__('[B][COLOR gold]KinoCheck Kids[/B][/COLOR]',__get_youtube_channel__('UC02ebHCrFJKxM4Achcl0tlw'),os.path.join(__addon_path__,'resources','icons','KinoCheck Kids.jpg'),'Plot ?',is_folder=True)
__add_item__('[B][COLOR blue]KinoCheck Home[/B][/COLOR]',__get_youtube_channel__('UCV297SPE0sBWzmhmACKJP-w'),os.path.join(__addon_path__,'resources','icons','KinoCheck Home.jpg'),'Plot ?',is_folder=True)
__add_item__('[B][COLOR lightcoral]Moviepilot Trailer[/B][/COLOR]',__get_youtube_user__('MoviepilotTrailer'),os.path.join(__addon_path__,'resources','icons','Moviepilot Trailer.jpg'),'Plot ?',is_folder=True)
__add_item__('[B][COLOR lightcoral]Moviepilot[/B][/COLOR]',__get_youtube_user__('moviepiloten'),os.path.join(__addon_path__,'resources','icons','Moviepilot.jpg'),'Plot ?',is_folder=True)
__add_item__('[B][COLOR lime]Moviepilot Kids[/B][/COLOR]',__get_youtube_user__('moviepilotKids'),os.path.join(__addon_path__,'resources','icons','moviepilotKids.jpg'),'Plot ?',is_folder=True)
__add_item__('[B][COLOR gold]KinoStarDE[/B][/COLOR]',__get_youtube_channel__('UCrFFdtcao4MGed7CC6tQy7w'),os.path.join(__addon_path__,'resources','icons','KinoStarDE.jpg'),'Plot ?',is_folder=True)
__add_item__('[B][COLOR skyblue]Warner Bros DE[/B][/COLOR]',__get_youtube_channel__('UCR88edMaCp9veFK6PVXyYpQ'),os.path.join(__addon_path__,'resources','icons','Warner Bros DE.jpg'),'Plot ?',is_folder=True)
__add_item__('[B][COLOR blue]Universal Pictures Germany[/B][/COLOR]',__get_youtube_user__('UniversalPicturesDE'),os.path.join(__addon_path__,'resources','icons','Universal Pictures Germany.jpg'),'Plot ?',is_folder=True)
#------------------------------------------------------------------------------------------------#

__set_end_of_directory__()