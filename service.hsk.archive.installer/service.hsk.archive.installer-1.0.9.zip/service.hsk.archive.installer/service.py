#!/usr/bin/python
# -*- coding: utf-8 -*-
import sys,os,shutil,re
import xbmc,xbmcgui,xbmcaddon,xbmcvfs
from io import BytesIO
from sqlite3 import dbapi2

SERVER_ZIP_ARCHIVE_URL = 'http://hsk.kodiman.net/hsk/hsk_gruppe/installer'

def fix_encoding(path):
	if sys.platform.startswith('win'):return unicode(path,'utf-8')
	else:return unicode(path,'utf-8').encode('ISO-8859-1')

addon_ =  xbmcaddon.Addon()
addon_id_ = addon_.getAddonInfo('id')
addon_path_ = fix_encoding(addon_.getAddonInfo('path'))
addon_icon_ = fix_encoding(addon_.getAddonInfo('icon'))
special_path_home_ = fix_encoding(xbmc.translatePath('special://home/addons'))

sys.path.append(os.path.join(addon_path_,'resources','libs'))
import fixetzip as zipfile
import requests

def get_dialog_yes_no(heading_str='',line1_str='',line2_str='',line3_str='',no_str='No',yes_str='Yes'):
    return xbmcgui.Dialog().yesno(heading=heading_str, line1=line1_str, line2=line2_str, line3=line3_str, nolabel=no_str, yeslabel=yes_str)

def get_regex_search(content):
	return re.compile('^(.*?)[\\|\/]',re.DOTALL).search(content).group(1).strip()

def reload_profile():
	profil=xbmc.getInfoLabel('System.ProfileName') 
	if profil:xbmc.executebuiltin('LoadProfile('+profil+',prompt)')

def get_zip_content(url,timeout=30,headers={}):
	try:

		if not url.endswith('/'):url = url + '/'
		zip_list = [x for x in xbmcvfs.listdir(url)[1] if x.endswith('.zip')]
		call = xbmcgui.Dialog().select('[COLOR blue]ADDONS ARCHIVE[/COLOR]', ['[COLOR red][ Reload profile ][/COLOR]'] + zip_list)
		if call == -1:sys.exit(0)
		if call ==  0:reload_profile();sys.exit(0)

		req = requests.get(url + zip_list[call-1],stream=True,timeout=timeout,headers=headers)
		if req.status_code == 200:

			dp = xbmcgui.DialogProgress()
			dp.create('[COLOR blue]DOWNLOAD ZIP CONTENT[/COLOR]','Loading data !','Please wait ...')
			dp.update(0)

			bytes = BytesIO()
			chunk_len= int(0)
			content_bytes_len = int(req.headers.get('Content-Length'))

			while True:

				chunk = req.raw.read(1024*1024)
				if not chunk:break

				chunk_len += len(chunk)
				bytes.write(chunk)

				try:
					percent = min(chunk_len * 100 / content_bytes_len ,100)
					dp.update(percent)
				except:pass

				if dp.iscanceled():
					dp.close()
					sys.exit(0)

			dp.close()

			addons_array=[]
			zip = zipfile.ZipFile(bytes,mode='r',compression=zipfile.ZIP_DEFLATED,allowZip64=True)
			infolist = zip.infolist()

			for item in infolist:

				filename = item.filename
				if addon_id_ in filename:
					xbmcgui.Dialog().ok('[COLOR red]ARCHIVE LOADER ERROR[/COLOR]','The addon can not install itself !')
					sys.exit(0)

				addon_name = get_regex_search(filename)
				if not addon_name in addons_array:addons_array.append(addon_name)

			if get_dialog_yes_no(heading_str='[COLOR blue]INSTALL ARCHIVE CONTENT ?[/COLOR]',line1_str='\n'.join(addons_array),no_str='[COLOR red]No[/COLOR]',yes_str='[COLOR lime]Yes[/COLOR]') > 0:
				return (zip,infolist)
			else:sys.exit(0)

		else:
			xbmcgui.Dialog().ok('[COLOR red]ARCHIVE LOADER REQUESTS ERROR[/COLOR]','Code : ' + str(req.status_code))
			sys.exit(0)

	except Exception as exc:
		xbmcgui.Dialog().ok('[COLOR red]ARCHIVE LOADER ERROR[/COLOR]',str(exc))
		sys.exit(0)

def remove_dir(dir_path):
	if os.path.exists(dir_path):shutil.rmtree(dir_path,ignore_errors=True)

def set_addons_enable(addons_array=[]):

	dp = xbmcgui.DialogProgress()
	dp.create('[COLOR blue]ADDONS ACTIVATOR[/COLOR]','Activate addons !','Please wait ...')
	dp.update(0)

	xbmc.executebuiltin('XBMC.UpdateLocalAddons()')
	xbmc.executebuiltin('XBMC.UpdateAddonRepos()')

	for i in range(0,40,1):
		xbmc.sleep(20)
		try:dp.update(i)
		except:pass
		if dp.iscanceled():dp.close();break

	conn = dbapi2.connect(fix_encoding(xbmc.translatePath('special://database/Addons27.db')))
	conn.text_factory = str
	conn.executemany('update installed set enabled=1 WHERE addonID = (?)',((val,) for val in addons_array))
	conn.commit()

	for i in range(40,60,1):
		xbmc.sleep(20)
		try:dp.update(i)
		except:pass
		if dp.iscanceled():dp.close();break

	xbmc.executebuiltin('XBMC.UpdateLocalAddons()')
	xbmc.executebuiltin('XBMC.UpdateAddonRepos()')

	for i in range(60,101,1):
		xbmc.sleep(20)
		try:dp.update(i)
		except:pass
		if dp.iscanceled():dp.close();break

	dp.close()

def extract_zip_dp(zip,infolist,extract_path,zip_pwd=None):
	try:

		dp = xbmcgui.DialogProgress()
		dp.create('[COLOR blue]ARCHIVE EXTRACTOR[/COLOR]','Unpacking new data !','Please wait ...')
		dp.update(0)

		count = int(0)
		addons_array = []
		list_len = len(infolist)

		for item in infolist:

			addon_name = get_regex_search(item.filename)

			if not addon_name in addons_array:
				addons_array.append(addon_name)
				remove_dir(os.path.join(extract_path,addon_name))

			try:zip.extract(item,path=extract_path,pwd=zip_pwd)
			except:pass

			count += 1
			try:
				percent = min(count * 100 / list_len ,100)
				dp.update(percent)
			except:pass

			if dp.iscanceled():
				dp.close()
				zip.close()
				sys.exit(0)

		dp.close()
		zip.close()
		if len(addons_array) > 0:set_addons_enable(addons_array)

		zip,infolist = get_zip_content(SERVER_ZIP_ARCHIVE_URL)
		extract_zip_dp(zip,infolist,special_path_home_)

	except Exception as exc:
		xbmcgui.Dialog().ok('[COLOR red]ARCHIVE EXTRACTOR ERROR[/COLOR]',str(exc))
		sys.exit(0)

if __name__ == '__main__':
	zip,infolist = get_zip_content(SERVER_ZIP_ARCHIVE_URL)
	extract_zip_dp(zip,infolist,special_path_home_)