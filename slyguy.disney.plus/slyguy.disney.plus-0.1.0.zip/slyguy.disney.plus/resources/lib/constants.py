AUTH_URL    = 'https://global.edge.bamgrid.com'
CONTENT_URL = 'https://search-api-disney.svcs.dssott.com/svc/search/v2/graphql/persisted/query'
LICENSE_URL = 'https://global.edge.bamgrid.com/widevine/v1/obtain-license'
PLAY_URL    = 'https://global.edge.bamgrid.com/media/{media_id}/scenarios/{scenario}'

API_KEY = 'ZGlzbmV5JmJyb3dzZXImMS4wLjA.Cu56AgSfBTDag5NiRA81oLHkDZfu5L3CKadnefEAY84'

PAGE_SIZE = 50

HEADERS = {
    'User-Agent': 'BAMSDK/v4.9.0 (disney-svod-3d9324fc 1.3.0.0; v2.0/v4.9.0; android; tv)',
    'x-bamsdk-client-id': 'disney-svod-3d9324fc',
    'x-bamsdk-platform': 'android-tv',
    'x-bamsdk-version': 'v4.9.0',
    'Accept-Encoding': 'gzip',
}