#!/usr/bin/python
# -*- coding: utf-8 -*-
import os,sys
import xbmc,xbmcgui,xbmcaddon,xbmcplugin

def fix_encoding(path):
	if sys.platform.startswith('win'):return unicode(path,'utf-8')
	else:return unicode(path,'utf-8').encode('ISO-8859-1')

addon_path = fix_encoding(xbmcaddon.Addon().getAddonInfo('path'))

def set_content(content):
	xbmcplugin.setContent(int(sys.argv[1]),content)

def set_view_mode(view_mode):
    xbmc.executebuiltin('Container.SetViewMode(%s)' % (view_mode))

def set_end_of_directory(succeeded=True,updateListing=False,cacheToDisc=False):
	xbmcplugin.endOfDirectory(handle=int(sys.argv[1]),succeeded=True,updateListing=False,cacheToDisc=False)

def get_youtube_live_stream(channel_id):# is_folder_bool=False
	return'plugin://plugin.video.youtube/play/?channel_id=%s&live=1' % channel_id

def get_youtube_video(video_id):# is_folder_bool=False
	return'plugin://plugin.video.youtube/?action=play_video&videoid=%s' % video_id

def get_youtube_playlist(playlist_id):# is_folder_bool=True
	return'plugin://plugin.video.youtube/playlist/%s/' % playlist_id

def get_youtube_channel(channel_id):# is_folder_bool=True
	return'plugin://plugin.video.youtube/channel/%s/' % channel_id

def get_youtube_user(user_id):# is_folder_bool=True
	return'plugin://plugin.video.youtube/user/%s/' % user_id

def add_item(title,url,icon,plot,is_folder=False):
	item=xbmcgui.ListItem(title,iconImage=icon,thumbnailImage=icon)
	item.setInfo(type='Video',infoLabels={'Title':title,'Plot':plot} )
	item.setProperty('IsPlayable','true')
	xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=item,isFolder=is_folder)

#-------------------#
#set_view_mode('50')
set_content('movies')
#-----------------------------------------------------------------------------------------------#
add_item('FilmSelect Deutsch',get_youtube_user('FilmSelect'),os.path.join(addon_path,'resources','icons','FilmSelect.jpg'),'Plot ?',is_folder=True)
add_item('FilmSelect Englisch',get_youtube_channel('UCT0hbLDa-unWsnZ6Rjzkfug'),os.path.join(addon_path,'resources','icons','FilmSelect Englisch.jpg'),'Plot ?',is_folder=True)
add_item('FilmSelect Espanol',get_youtube_channel('UCEakdPLL42qApJnoeWCwo2Q'),os.path.join(addon_path,'resources','icons','FilmSelect Espanol.jpg'),'Plot ?',is_folder=True)
add_item('FilmSelect Russisch',get_youtube_channel('UCDgVWEC93NuidEeDxWHAIFg'),os.path.join(addon_path,'resources','icons','FilmSelect Russisch.jpg'),'Plot ?',is_folder=True)
add_item('FilmSelect France',get_youtube_channel('UCnnWUdZz7XC01pbNDzW8Nig'),os.path.join(addon_path,'resources','icons','FilmSelect France.jpg'),'Plot ?',is_folder=True)
add_item('FilmSelect Italiano',get_youtube_channel('UCavDCz6iNM65hAexLSvr1hw'),os.path.join(addon_path,'resources','icons','FilmSelect Italiano.jpg'),'Plot ?',is_folder=True)
add_item('FilmSelect Türkiye',get_youtube_channel('UC-7KEyxLIOx5K9tRUgQPpxg'),os.path.join(addon_path,'resources','icons','FilmSelect Italiano.jpg'),'Plot ?',is_folder=True)
add_item('Netflix',get_youtube_user('netflixdach'),os.path.join(addon_path,'resources','icons','Netflix.jpg'),'Plot ?',is_folder=True)
add_item('FILMSTARTSTV',get_youtube_user('FILMSTARTSTV'),os.path.join(addon_path,'resources','icons','FILMSTARTSTV.jpg'),'Plot ?',is_folder=True)
add_item('KinoCheck',get_youtube_channel('UCOL10n-as9dXO2qtjjFUQbQ'),os.path.join(addon_path,'resources','icons','KinoCheck.jpg'),'Plot ?',is_folder=True)
add_item('KinoCheck Kids',get_youtube_channel('UC02ebHCrFJKxM4Achcl0tlw'),os.path.join(addon_path,'resources','icons','KinoCheck Kids.jpg'),'Plot ?',is_folder=True)
add_item('KinoCheck Home',get_youtube_channel('UCV297SPE0sBWzmhmACKJP-w'),os.path.join(addon_path,'resources','icons','KinoCheck Home.jpg'),'Plot ?',is_folder=True)

#-----------------------------------------------------------------------------------------------#

set_end_of_directory()