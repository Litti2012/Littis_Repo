#!/usr/bin/python
# -*- coding: utf-8 -*-
import os,sys
import xbmcgui

if sys.version_info.major == 2:import fixetzipfile as zipfile
elif sys.version_info.major == 3:import zipfile

def check_zip(zip_path):
	try:zip = zipfile.ZipFile(zip_path,mode='r',compression=zipfile.ZIP_STORED,allowZip64=True)
	except BadZipfile:return False
	return True

def extract_zip(zip_path,extract_path,zip_pwd='',extract_save_list=[]):

	if sys.version_info.major == 2:zip_pwd=zip_pwd
	elif sys.version_info.major == 3:zip_pwd=bytes(zip_pwd,'utf-8')

	dp = xbmcgui.DialogProgress()
	dp.create('[COLOR blue]EXTRACTOR[/COLOR]','Extract data !','Please wait ...')
	dp.update(0)

	try:zip = zipfile.ZipFile(zip_path,mode='r',compression=zipfile.ZIP_STORED,allowZip64=True)
	except BadZipfile:return False

	count = int(0)
	list_len = len(zip.infolist())
	for item in zip.infolist():

		count += 1
		try:
			percent = int(min(count * 100 / list_len ,100))
			dp.update(percent,'Extract data:',item.filename)
		except:pass

		if not any((x in item.filename for x in extract_save_list)):
			try:zip.extract(item,path=extract_path,pwd=zip_pwd)
			except:pass
			

		if dp.iscanceled():break

	zip.close()
	dp.close()

	if dp.iscanceled():return False
	else:return True