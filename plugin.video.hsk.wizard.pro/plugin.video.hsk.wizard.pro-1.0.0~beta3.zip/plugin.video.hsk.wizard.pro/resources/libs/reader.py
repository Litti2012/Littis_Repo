#!/usr/bin/python
# -*- coding: utf-8 -*-
import os,sys,shutil
import xbmc,xbmcgui

def read_log(addon,log_file_path,error_log_file_path,log_mode='log'):

	if os.path.exists(error_log_file_path):
		os.unlink(error_log_file_path)

	if os.path.exists(log_file_path):
	
		if log_mode == 'log':

			with open(log_file_path,'rb',buffering=1024*32) as fi:
				log_file_content = str(fi.read())
				xbmcgui.Dialog().textviewer(heading='[COLOR blue]LOG READER[/COLOR]',text=log_file_content.replace('ERROR:','[COLOR red]ERROR[/COLOR]:').replace('WARNING:','[COLOR orange]WARNING[/COLOR]:'))

		elif log_mode == 'ip_log':
		
			ip = addon.getSetting('webinterface_ip').strip()
			if not ip:
				ip = xbmc.getIPAddress()
				addon.setSetting('webinterface_ip',ip)

			port = addon.getSetting('webinterface_port').strip()

			username = addon.getSetting('webinterface_username').strip()
			password = addon.getSetting('webinterface_password').strip()

			shutil.copyfile(log_file_path,error_log_file_path)
			xbmcgui.Dialog().ok(heading='[COLOR blue]IP LOG ADDRESS[/COLOR]',line1='[COLOR red]http://' + username + ':' + password + '@' + ip + ':' + port + '/kodi.log[/COLOR]',line2='[COLOR blue]Activate the addon under web interface:[/COLOR]',line3='[COLOR blue]Settings - Services - Control - Allow remote control via HTTP[/COLOR]')
			
	else:xbmcgui.Dialog().ok(heading='[COLOR red]LOG READER ERROR[/COLOR]',line1='No log file found !',line2='',line3='')