<?php
$im = imagecreatefrompng("index.png");
header('Content-Type: image/png');
imagepng($im);
imagedestroy($im);
?>