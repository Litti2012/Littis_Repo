<?php
echo crypt('xxx').'<br />';
echo realpath('help.php');
?>