#!/usr/bin/python
# -*- coding: utf-8 -*-
import os,sys
import xbmc,xbmcgui,xbmcplugin,xbmcaddon

def fix_encoding(path):
	if sys.platform.startswith('win'):return unicode(path,'utf-8')
	else:return unicode(path,'utf-8').encode('ISO-8859-1')
	
addon_path = fix_encoding(xbmcaddon.Addon().getAddonInfo('path'))

def set_content(content):
	xbmcplugin.setContent(int(sys.argv[1]),content)
	
def set_view_mode(view_mode):
    xbmc.executebuiltin('Container.SetViewMode(%s)' % (view_mode))
	
def set_end_of_directory(succeeded=True,updateListing=False,cacheToDisc=False):
	xbmcplugin.endOfDirectory(handle=int(sys.argv[1]),succeeded=True,updateListing=False,cacheToDisc=False)
	
def get_youtube_live_stream(channel_id):
	return'plugin://plugin.video.youtube/play/?channel_id=%s&live=1' % channel_id

def get_youtube_video(video_id):
	return'plugin://plugin.video.youtube/?action=play_video&videoid=%s' % video_id

def get_youtube_playlist(playlist_id):
	return'plugin://plugin.video.youtube/playlist/%s/' % playlist_id

def get_youtube_channel(channel_id):
	return'plugin://plugin.video.youtube/channel/%s/' % channel_id

def get_youtube_user(user_id):
	return'plugin://plugin.video.youtube/user/%s/' % user_id
	
def get_youtube_search(search_text):
	return'plugin://plugin.video.youtube/search/?q=%s' % search_text
	
def add_item(title,url,icon,plot,is_folder=False):
	item=xbmcgui.ListItem(title,iconImage=icon,thumbnailImage=icon)
	item.setInfo(type='Video',infoLabels={'Title':title,'Plot':plot} )
	item.setProperty('IsPlayable','true')
	xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=item,isFolder=is_folder)
	
#-------------------#
#set_view_mode('50')
set_content('Musik')
#-----------------------------------------------------------------------------------------------#
add_item('[B][COLOR indigo]Kontor.TV[/B][/COLOR]',get_youtube_user('kontor'),os.path.join(addon_path,'resources','icons','Kontor.TV.jpg'),'Plot ?',is_folder=True)
add_item('[B][COLOR skyblue]Scooter [/B][/COLOR]',get_youtube_user('scooter'),os.path.join(addon_path,'resources','icons','Scooter.jpg'),'Plot ?',is_folder=True)
add_item('[B][COLOR red]VEVO [/B][/COLOR]',get_youtube_user('VEVO'),os.path.join(addon_path,'resources','icons','VEVO.jpg'),'Plot ?',is_folder=True)
add_item('[B][COLOR gold]TOP 100 Charts Germany 2019[/B][/COLOR]',get_youtube_playlist('PL3oW2tjiIxvQBahbPHDWS2sqd_vQg8a20'),os.path.join(addon_path,'resources','icons','TOP 100 Charts Germany 2019.jpg'),'Plot ?',is_folder=True)
add_item('[B][COLOR peru]German TOP 100 Single Charts 2019[/B][/COLOR]',get_youtube_playlist('PLD7SPvDoEddZ4awWJjYEQdI10UP-9sGkO'),os.path.join(addon_path,'resources','icons','German TOP 100 Single Charts 2019.jpg'),'Plot ?',is_folder=True)
#-----------------------------------------------------------------------------------------------#

set_end_of_directory()