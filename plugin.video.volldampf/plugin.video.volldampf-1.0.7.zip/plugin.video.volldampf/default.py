# -*- coding: utf-8 -*-

import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.volldampf'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')


channellist=[
        ("Dampf Wolke + Live", "channel/UCISsXw8IMfoGNwUmbNRS0FA", 'https://yt3.ggpht.com/a-/AN66SAy2g80hSCvR0q2nbpN8rEtCDYg2k3SfAn47kA=s288-mo-c-c0xffffffff-rj-k-no'),
		("Dampfdidas", "channel/UCvj-5T3JgPwzCdyZWCioRhg", 'https://yt3.ggpht.com/a-/AN66SAxhOvsm2OdE5i8L3SYJBIuOD3fgpkn-EKHEmg=s288-mo-c-c0xffffffff-rj-k-no'),
		("Dampfeuphorie", "channel/UCIFLrXajveZSf8MPV4cBKqA", 'https://yt3.ggpht.com/a-/AN66SAznYRBi4CsuzJ0RyruuSpn11iRHMur6QVe3Tw=s288-mo-c-c0xffffffff-rj-k-no'),
		("Diane Smokewolke", "channel/UC881N-bffRaj0Ym4n9MRsRA", 'https://yt3.ggpht.com/a-/AN66SAxBDJYrJFBXhNwyyrDwf-LRwIV_GunuSXSstg=s288-mo-c-c0xffffffff-rj-k-no'),
		("Vapor Frank", "channel/UCpjmLS3c_Wt5onHhPigU6LA", 'https://yt3.ggpht.com/a-/AN66SAy5yAazazxv83HNCfH8DVddwXTSh0T7-GVR-A=s288-mo-c-c0xffffffff-rj-k-no'),
		("Dampfer Tutorial's", "channel/UC7Aq4vmhzOPOSOq_vNPqFng", 'https://yt3.ggpht.com/a-/AN66SAwqjiWy0a5uhMCh8adZk_kRAL97mamMfYZf4Q=s288-mo-c-c0xffffffff-rj-k-no'),
		("Steamshots TV", "channel/UCBfklet-t48PRWltcHKk-OA", 'https://yt3.ggpht.com/a-/AN66SAz44ZQfxGaR6A6QaooAqO1qzKvwQUjjXCy08g=s288-mo-c-c0xffffffff-rj-k-no'),
		("Tony Vapes", "channel/UC3V37yO7JXTYBdnGPDCUZpA", 'https://yt3.ggpht.com/a-/AN66SAwl3wvN9yFlwvdv2-2nJbox358I27p7hdDV0w=s288-mo-c-c0xffffffff-rj-k-no'),
		("Dampfole", "channel/UCHHLNOIQzFBpLRlf6QZ6ozw", 'https://yt3.ggpht.com/a-/AN66SAztMoUpQMBiPwRlMxDgVKQi69qZLqnSWgkrLA=s288-mo-c-c0xffffffff-rj-k-no'),
		("Dampfer Girl", "channel/UCByjeB-1YLP3UH0Yw2AWN3Q", 'https://yt3.ggpht.com/a-/AN66SAxQNC1D7IlR0Qmc6gKkBt4Z6NOzxEuvUwFyvA=s288-mo-c-c0xffffffff-rj-k-no'),
		("Mr.Wuerzig", "channel/UCgG_kfNF4yPL7rDWrzUh2wQ", 'https://yt3.ggpht.com/a-/AN66SAyWaYBkgxPcKFcqiWBVpBxiMuODHFUk1UXW_A=s288-mo-c-c0xffffffff-rj-k-no'),
		("DampfPlauderer TV", "channel/UCIfg9t9daI5mE5SUEh3rzjQ", 'https://yt3.ggpht.com/a-/AN66SAyeV2z3vPEUNIgXS-FPYjPy-c0rrbG_V4a2jA=s288-mo-c-c0xffffffff-rj-k-no'),
		("Vape Scene Investigation", "channel/UCtiWrbVf93tJyzA1Tj28S8w", 'https://yt3.ggpht.com/a-/AN66SAwT7pRLCnQ1CS5FnfKLBT1TC3Cpicc2XLlU-g=s288-mo-c-c0xffffffff-rj-k-no'),
		("Guruschgabaschga", "channel/UCXnC3uIgTyBrIqB__q8M4_g", 'https://yt3.ggpht.com/a-/AN66SAwRl502dOlKaJJQhnXVatyHAgrdzLVcleaEKQ=s288-mo-c-c0xffffffff-rj-k-no'),
		("Dampfpate", "channel/UCfIqxSk2g8DhCgNHsyGRn-A", 'https://yt3.ggpht.com/a-/AN66SAxRasBb0jv-2rZa7AvOQ3c1VQULWWf-ihPg4w=s288-mo-c-c0xffffffff-rj-k-no'),
		("Dampf Druide", "channel/UC200jxduWYuQ4GGsiLmpU6Q", 'https://yt3.ggpht.com/a-/AN66SAz_CXw9_kVLcqOOUC5oxbhBavo0l59FVR6fQg=s288-mo-c-c0xffffffff-rj-k-no'),
		("JD VAPES", "channel/UCWKeT9Nq1hJyWn9iuzXqDBw", 'https://yt3.ggpht.com/a-/AN66SAxobStWsZsunNzPytyBc1_rEtcUft0CLScqeA=s288-mo-c-c0xffffffff-rj-k-no'),
		("Vaping Chrisch", "channel/UC2y_jCYZfeNOE-jYfWBQKGA", 'https://yt3.ggpht.com/a-/AN66SAxi4iZYnzE-Y2yljrAUBWiAoELLJqF1FMjCJg=s288-mo-c-c0xffffffff-rj-k-no'),
		("Ich rauche nicht", "channel/UCwUEe36PB_NDxEGNxkRLOfg", 'https://yt3.ggpht.com/a-/AN66SAxzZY6aS62hRyJg1tVcEHuzRuSUeJXGxj4XDg=s288-mo-c-c0xffffffff-rj-k-no'),
		("Vape Oase", "channel/UC3kvXKyLM7D1bFQS1rwHU5g", 'https://yt3.ggpht.com/a-/AN66SAxHkxunEE7_zkGH4v8IPyjbstDtKcEabCOqLA=s288-mo-c-c0xffffffff-rj-k-no'),
		("sunny smoke Jens Thorsten Voigt", "channel/UCcqg0N2l1T8MJIQ3aHalMKw", 'https://yt3.ggpht.com/a-/AN66SAy9PJO7aBpjFZ5rvxhyEupRDVtGV_nkhFo4xg=s288-mo-c-c0xffffffff-rj-k-no'),
		("DampfTuber TV", "channel/UCcYp6ug2st8XdUKTXnOIkUg", 'https://yt3.ggpht.com/a-/AN66SAyxFOH2kLaNqCXWwXTAanoiTFW-RKWfbWr_jw=s288-mo-c-c0xffffffff-rj-k-no'),
		("Didi Diamond", "channel/UCmioovkMOapo4HcESk-y91A", 'https://yt3.ggpht.com/a-/AN66SAy-UFRla0WM4uvW1g5zc4w3VoEsgQm-TUdTPg=s288-mo-c-c0xffffffff-rj-k-no'),
		("Dampferspoint TV", "channel/UCAbSQReutjnRpdkqBmFLgSQ", 'https://yt3.ggpht.com/a-/AN66SAw25cF7Oo2mpLJAAlKVwYZvQw6Pug9kZaeKQA=s288-mo-c-c0xffffffff-rj-k-no'),
		("Dampfer Monteur", "channel/UC6PsiiktsCDB6uWnV-W1Tew", 'https://yt3.ggpht.com/a-/AN66SAzqAH6YWV2ndoF64NqaQtjw2JWeIEqOUMRXcA=s288-mo-c-c0xffffffff-rj-k-no'),
		("Cloudcatcher", "channel/UC1no-5-PFs9EbRXt-5ia-yg", 'https://yt3.ggpht.com/a-/AN66SAzbek_fy_zb9Nzrt3ejF6S-re7Poqk88YWlHg=s288-mo-c-c0xffffffff-rj-k-no'),
		("Dampfpost Bavaria", "channel/UC1XAKpfwcLX-uvbWMTctiGg", 'https://yt3.ggpht.com/a-/AN66SAwnFcEpWufx5kovw_KWwjeayWY4vMDR0pX5bA=s288-mo-c-c0xffffffff-rj-k-no'),
		("Schweizer Vapor Stammtisch S V S", "channel/UCoLEDYaGe1aAvIKkufsdW1A", 'https://yt3.ggpht.com/a-/AN66SAyS0nxbeGCCaoIagzmRJNIV-a0ErqHu45UzZw=s288-mo-c-c0xffffffff-rj-k-no'),
		("Dampferstation", "channel/UC0x0LPM1_XCbzC8SYACIdoQ", 'https://yt3.ggpht.com/a-/AN66SAxIP-D2ZHzE8eOVRMhdXVHB9u6sJcNF7rL55g=s288-mo-c-c0xffffffff-rj-k-no'),
]



# Entry point
def run():
    plugintools.log("youtubeAddon.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("youtubeAddon.main_list "+repr(params))

for name, id, icon in channellist:
	plugintools.add_item(title=name,url="plugin://plugin.video.youtube/"+id+"/",thumbnail=icon,folder=True )



run()