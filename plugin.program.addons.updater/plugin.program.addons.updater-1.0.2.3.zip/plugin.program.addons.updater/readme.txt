Mit diesem Addon kann von jedem beliebigem Github ein Update geladen werden

Die Addons sind in der data.txt einzutragen

Die schreibweise URLResolver ist für private Github Repo Branchen.

Die folgende Schreibweise für ein öffentliches Github (z.B Joyn):
Joyn*https://github.com/fayer3/plugin.video.joyn_app/archive/master.zip*joyn.png

Unter resources/images/ werden die dazugehörigen Icons abgelegt. Diese werde dann im Addon Menü angezeigt und sind erforderlich

Anwendung des Addons:

Addon starten
Wählen was aktualisiert werden soll
Klicken und warten bis die Meldung kommt: 

- Write New data (mit Addon ID und Version)

Dann war das update erfolgreich