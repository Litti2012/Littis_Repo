#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmcaddon
xbmcaddon.Addon().openSettings()