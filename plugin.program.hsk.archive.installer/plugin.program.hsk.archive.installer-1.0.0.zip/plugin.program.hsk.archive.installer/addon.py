#!/usr/bin/python
# -*- coding: utf-8 -*-
from io import BytesIO
from sqlite3 import dbapi2
import os,sys,re,urlparse,shutil,math,time,datetime
import xbmc,xbmcgui,xbmcplugin,xbmcaddon,xbmcvfs,inputstreamhelper

ZIP_ARCHIVE_URL_LIST = 'https://hsk.kodiman.net/hsk/hsk_gruppe/archive_installer/urls.txt'

def fix_encoding(path):
	if sys.platform.startswith('win'):return unicode(path,'utf-8')
	else:return unicode(path,'utf-8').encode('ISO-8859-1')

addon =  xbmcaddon.Addon()
addon_id = addon.getAddonInfo('id')
addon_path = fix_encoding(addon.getAddonInfo('path'))

special_path_home = fix_encoding(xbmc.translatePath('special://home/'))
special_path_cdm = fix_encoding(xbmc.translatePath('special://home/cdm'))
special_path_inputstream = fix_encoding(xbmc.translatePath('special://home/addons/inputstream.adaptive'))

sys.path.append(os.path.join(addon_path,'resources','libs'))
import fixetzipfile as zipfile
import requests

def xbmc_sleep_ms(ms):
	xbmc.sleep(ms)

def get_domain(url):
	return urlparse.urlparse(url).netloc

def remove_dir(path):
	if os.path.exists(path):
		shutil.rmtree(path,ignore_errors=True)

def reload_profile():
	profil=xbmc.getInfoLabel('System.ProfileName') 
	if profil:xbmc.executebuiltin('LoadProfile('+profil+',prompt)')

def check_inputstream():
	if inputstreamhelper.Helper('mpd', drm='com.widevine.alpha').check_inputstream():
		xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"inputstream.adaptive", "enabled":true}}')

def delete_inputstream():
	remove_dir(special_path_cdm)
	remove_dir(special_path_inputstream)
	reload_profile()

def get_convert_size(size):
	if (size == 0 ):return '0 B'
	units = (' B',' KB',' MB',' GB',' TB',' PB',' EB',' ZB',' YB' )
	i = int(math.floor( math.log(size,1024)))
	p = math.pow(1024,i)
	size = "%.2f" % round((size / p ),2)
	return '{}{}'.format(size,units[i])

request_headers = {
	'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
	'Accept-Language':'de-DE,de;q=0.9,en-US;q=0.8,en;q=0.7',
	'Connection':'keep-alive',
	'Cache-Control':'max-age=0',
	'Upgrade-Insecure-Requests':'1',
	'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36'}

def request_download_file_bytes_dp(url,timeout=30,headers={}):

	fi = xbmcvfs.File(url)
	read = fi.read()
	fi.close()
	if read:

		counter = 0
		url_data_list = []
		zip_info_list = []
		zip_data_list = []
		data_list = read.splitlines()
		url_list_len  = len(data_list)

		dp = xbmcgui.DialogProgress()
		dp.create('[COLOR blue]ARCHIVE LOADER FOUND ( [COLOR red]' + str(url_list_len) + '[/COLOR] ) URLS[/COLOR]','Loading url !','Please wait ...')
		dp.update(0)

		try:

			for data in data_list:

				url = data.split('*')[1].strip()
				if not url.endswith('/'):url = url + '/'

				counter += 1
				percent = min(counter * 100 / url_list_len, 100)
				dp.update(percent,'Loading url:',get_domain(url))

				if dp.iscanceled():dp.close()
				xbmc_sleep_ms(500)

				for zip_file in xbmcvfs.listdir(url)[1]:
					if zip_file.endswith('.zip'):
						url_data_list.append(url)
						zip_info_list.append('[COLOR blue]' + zip_file +'[/COLOR] [COLOR red][ ' + data.split('*')[0] + ' ][/COLOR]')
						zip_data_list.append(zip_file)

			xbmc_sleep_ms(500)
			dp.close()

			call = xbmcgui.Dialog().select('[COLOR blue]ADDONS ARCHIVE ([/COLOR] [COLOR red]Reload profile before exiting ![/COLOR] [COLOR blue])[/COLOR]', ['[COLOR red][ RELOAD PROFILE ][/COLOR]','[COLOR red][ CHECK INPUTSTREAM ][/COLOR]','[COLOR red][ DELETE INPUTSTREAM ][/COLOR]'] + zip_info_list)

			if call == -1:sys.exit(0)
			elif call ==  0:reload_profile();run()
			elif call ==  1:check_inputstream();run()
			elif call ==  2:delete_inputstream();run()
			elif call >=  3:

				req = requests.get(url_data_list[call-3] + zip_data_list[call-3],stream=True,timeout=timeout,headers=headers)
				if req.status_code == 200:

					dp = xbmcgui.DialogProgress()
					dp.create('[COLOR blue]DOWNLOAD ARCHIVE CONTENT[/COLOR]','Loading data !','Please wait ...')
					dp.update(0)

					bytes = BytesIO()
					chunk_len= int(0)
					start_time = time.time();xbmc_sleep_ms(1)
					content_bytes_len = int(req.headers.get('Content-Length'))

					while True:

						chunk = req.raw.read(1024*16)
						if not chunk:break

						chunk_len += len(chunk)
						bytes.write(chunk)

						try:

							percent = min(chunk_len * 100 / content_bytes_len, 100)
							speed = (chunk_len / (time.time() - start_time))

							if speed > 0: remaining_sec = ((content_bytes_len - chunk_len) / speed)
							else: remaining_sec = 0

							s = 'Loaded: %s of %s - ( %s%% )'% (get_convert_size(chunk_len),get_convert_size(content_bytes_len),str(percent))
							ss = 'Speed: %s/s' % (get_convert_size(speed))
							sss = 'Remaining time: %s' % datetime.timedelta(seconds=remaining_sec)
							dp.update(percent,s,ss,sss)

						except:pass

						if dp.iscanceled():
							req.close()
							dp.close()
							return

					req.close()
					dp.close()
					return bytes

				else:
					xbmcgui.Dialog().ok('[COLOR red]ARCHIVE LOADER REQUESTS ERROR[/COLOR]',str(req.status_code))
					sys.exit(0)

		except Exception as exc:
			xbmcgui.Dialog().ok('[COLOR red]ARCHIVE LOADER ERROR[/COLOR]',str(exc))
			sys.exit(0)

def get_data_info(zip_bytes):

	try:zip = zipfile.ZipFile(zip_bytes,mode='r',compression=zipfile.ZIP_STORED,allowZip64=True)
	except BadZipfile:raise Exception('[COLOR red]BAD ZIPFILE ![/COLOR]')

	addon_id_list = []
	addon_info_list = []
	new_zip_infolist = []
	check_inputstream = False

	for item in zip.infolist():
		addons_data_match = re.compile(r'(addons|addon_data)(?:\/|\\)(.*?)(?:\/|\\)',re.DOTALL).search(item.filename)
		if addons_data_match:

			new_zip_infolist.append(item)
			if addons_data_match.group(1) == 'addons':

				if item.filename.endswith('addon.xml'):

					xml_content = zip.read(item.filename)
					if 'inputstream.adaptive' in xml_content:check_inputstream = True
					xml_match = re.compile(r'id=\"(.*?)\"[\s\S]*?version=\"(.*?)\"',re.DOTALL).search(xml_content)

					if xml_match:
						addon_id_list.append(xml_match.group(1))
						addon_info_list.append('[COLOR blue]' + xml_match.group(1) +' - '+ xml_match.group(2) +'[/COLOR]')

			elif (addons_data_match.group(1) == 'addon_data' and not '[COLOR yellow]' + addons_data_match.group(2) + '[/COLOR]' in addon_info_list):
				addon_info_list.append('[COLOR yellow]' + addons_data_match.group(2) + '[/COLOR]')
				
	if len(addon_info_list) > 0:
		if xbmcgui.Dialog().yesno(heading='[COLOR blue]INSTALL ARCHIVE CONTENT ( [/COLOR][COLOR red]' + get_convert_size(len(zip_bytes.getvalue())) + '[/COLOR][COLOR blue] ) ?[/COLOR]', line1='\n'.join(addon_info_list), line2='', line3='', nolabel='[COLOR red]No[/COLOR]', yeslabel='[COLOR lime]Yes[/COLOR]') > 0:
			return (zip,new_zip_infolist,addon_id_list,check_inputstream)
		else:sys.exit(0)
	else:
		xbmcgui.Dialog().ok('ARCHIVE INSTALLER INFO','No content found !')
		sys.exit(0)

def extract_zip_dp(zip,zip_infolist,extract_path,zip_pwd=None,save_list=[]):

	dp = xbmcgui.DialogProgress()
	dp.create('[COLOR blue]EXTRACT ARCHIVE[/COLOR]','Extract data !','Please wait ...')
	dp.update(0)

	count = int(0)
	list_len = len(zip_infolist)
	extract_path = os.path.abspath(extract_path)

	for item in zip_infolist:
		remove_dir(os.path.join(extract_path,item.filename))
		try:zip.extract(item,path=extract_path,pwd=zip_pwd)
		except:pass
			
		count += 1
		try:
			percent = min(count * 100 / list_len ,100)
			dp.update(percent,'Extract data:',item.filename)
		except:pass

		if dp.iscanceled():break

	zip.close()
	dp.close()

def set_addons_enable(addons_array=[]):

	dp = xbmcgui.DialogProgress()
	dp.create('[COLOR blue]ADDONS ACTIVATOR[/COLOR]','Activate addons !','Please wait ...')
	dp.update(0)

	xbmc.executebuiltin('XBMC.UpdateLocalAddons()')
	xbmc.executebuiltin('XBMC.UpdateAddonRepos()')

	for i in range(0,40,1):
		xbmc.sleep(20)
		try:dp.update(i)
		except:pass
		if dp.iscanceled():dp.close();break

	conn = dbapi2.connect(fix_encoding(xbmc.translatePath('special://database/Addons27.db')))
	conn.text_factory = str
	conn.executemany('update installed set enabled=1 WHERE addonID = (?)',((val,) for val in addons_array))
	conn.commit()

	for i in range(40,60,1):
		xbmc.sleep(20)
		try:dp.update(i)
		except:pass
		if dp.iscanceled():dp.close();break

	xbmc.executebuiltin('XBMC.UpdateLocalAddons()')
	xbmc.executebuiltin('XBMC.UpdateAddonRepos()')

	for i in range(60,101,1):
		xbmc.sleep(20)
		try:dp.update(i)
		except:pass
		if dp.iscanceled():dp.close();break

	dp.close()

def run():

	zip_bytes = request_download_file_bytes_dp(ZIP_ARCHIVE_URL_LIST,timeout=30,headers=request_headers)
	if zip_bytes:

		data = get_data_info(zip_bytes)
		if data:

			if(data[0] and len(data[1]) > 0):
				xbmc_sleep_ms(500)
				extract_zip_dp(data[0],data[1],special_path_home,zip_pwd=None,save_list=[addon_id])

			if len(data[2]) > 0:
				xbmc_sleep_ms(500)
				set_addons_enable(data[2])

			if data[3] == True:
				xbmc_sleep_ms(500)
				check_inputstream()

if __name__ == '__main__':run()