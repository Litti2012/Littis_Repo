# -*- coding: utf-8 -*-

# Addon: Kinder serien
# Author: Litti19928


import os           
import xbmc         
import xbmcaddon    
import xbmcplugin   



from koding import route, Addon_Setting, Add_Dir, Find_In_Text, Open_URL, OK_Dialog
from koding import Open_Settings, Play_Video, Run, Text_File

debug        = Addon_Setting(setting='debug')       
addon_id     = xbmcaddon.Addon().getAddonInfo('id') 


BASE  = "plugin://plugin.video.youtube/user/"
BASE2 = "plugin://plugin.video.youtube/channel/"


YOUTUBE_CHANNEL_ID_1 = "DisneyJuniorGermany"
YOUTUBE_CHANNEL_ID_2 = "DisneyChannelGermany"
YOUTUBE_CHANNEL_ID_3 = "UChcDNaLm0F8GZY4fRhZEAeQ"
YOUTUBE_CHANNEL_ID_4 = "cartoonnetworkde"
YOUTUBE_CHANNEL_ID_5 = "UC05FqpJgblXX4JjT-fqm8Uw"
YOUTUBE_CHANNEL_ID_6 = "UCNclt7O1bO7hz8Mari68neg"
YOUTUBE_CHANNEL_ID_7 = "UCRmdnsnElWlSHS5VM2kV4Uw"
YOUTUBE_CHANNEL_ID_8 = "UC1gSKVovUYLmXoDnsTY039Q"
YOUTUBE_CHANNEL_ID_9 = "UCA_DdzBmf5yNaxMpVGwZV4g"
YOUTUBE_CHANNEL_ID_10 = "pinkpanthervideo"
YOUTUBE_CHANNEL_ID_11 = "UCx0N1wFkyDoc3_WApuExy9w"
YOUTUBE_CHANNEL_ID_12 = "UCQU3PO2g_rmqbmr8VJWvrsA"


@route(mode='main_menu')
def Main_Menu():
    

    my_message= "{'title' : '[B][COLOR lime]informationen und Updates[/B][/COLOR]', 'msg' : \"[B][COLOR red]Willkommen in der kinderstube hier findest du alle kinder serien[/B][/COLOR]\"}"

    Add_Dir(
        name="[B][COLOR lime]informationen und Updates[/B][/COLOR]", url=my_message, mode="simple_dialog", folder=False,
        icon="https://cdn2.iconfinder.com/data/icons/picons-basic-2/57/basic2-087_info-512.png")
        

    Add_Dir( 
        name="[B][COLOR red]Disney Junior[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1+"/", folder=True,
        icon="https://yt3.ggpht.com/a-/AN66SAwlOZwCOusAW5LimA6hdoVsjZw6cN6Xc9HMEA=s288-mo-c-c0xffffffff-rj-k-no")

    Add_Dir( 
        name="[B][COLOR skyblue]Disney Channel[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_2+"/", folder=True,
        icon="https://yt3.ggpht.com/a-/AN66SAxe1mKZGsCCXOC0QxuCCMzTPmbagXuj6klluQ=s288-mo-c-c0xffffffff-rj-k-no")

    Add_Dir( 
        name="[B][COLOR white]Boomerang [/B][/COLOR]", url=BASE2+YOUTUBE_CHANNEL_ID_3+"/", folder=True,
        icon="https://yt3.ggpht.com/a-/AN66SAwJREt_kfHxRH4UYzmJkmv48L400AUvXJrUag=s288-mo-c-c0xffffffff-rj-k-no")

    Add_Dir( 
        name="[B][COLOR teal]Cartoon Network[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_4+"/", folder=True,
        icon="https://yt3.ggpht.com/a-/AN66SAz4x2S2bim3kwxOpRXsII5ryjwvHAAUFUZj3w=s288-mo-c-c0xffffffff-rj-k-no")


    Add_Dir( 
        name="[B][COLOR pink]Die Powerpuff Girls[/B][/COLOR]", url=BASE2+YOUTUBE_CHANNEL_ID_5+"/", folder=True,
        icon="https://yt3.ggpht.com/a-/AN66SAyC5hFZDh5BCSAXA4VNcoGBj1tWlQtZkpqhsA=s288-mo-c-c0xffffffff-rj-k-no")

    Add_Dir( 
        name="[B][COLOR red]Peppa Pig[/B][/COLOR]", url=BASE2+YOUTUBE_CHANNEL_ID_6+"/", folder=True,
        icon="https://yt3.ggpht.com/a-/AN66SAy8YKM4CnxBjd-fvvYJE-K_Ssthf82dSuY1kQ=s288-mo-c-c0xffffffff-rj-k-no")
		
    Add_Dir( 
        name="[B][COLOR yellow]Caillou[/B][/COLOR]", url=BASE2+YOUTUBE_CHANNEL_ID_7+"/", folder=True,
        icon="https://yt3.ggpht.com/a-/AN66SAzPXogSduh5PlRPkZT2pceSvEQlHkzCtaCu6Q=s288-mo-c-c0xffffffff-rj-k-no")
		
		
    Add_Dir( 
        name="[B][COLOR yellow]Bob der Baumeister[/B][/COLOR]", url=BASE2+YOUTUBE_CHANNEL_ID_8+"/", folder=True,
        icon="https://yt3.ggpht.com/a-/AN66SAzTRkM0Km_ovTwp2Hs3Tm_6y8BeUNvxSrIX9A=s288-mo-c-c0xffffffff-rj-k-no")
		
    Add_Dir( 
        name="[B][COLOR sienna]Mascha und der Bär[/B][/COLOR]", url=BASE2+YOUTUBE_CHANNEL_ID_9+"/", folder=True,
        icon="https://yt3.ggpht.com/a-/AN66SAwA0uDMFNAUpex12d4NzRHVdSIwxWO3azKRRQ=s288-mo-c-c0xffffffff-rj-k-no")
		
    Add_Dir( 
        name="[B][COLOR pink]Der Rosarote Panther[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_10+"/", folder=True,
        icon="https://yt3.ggpht.com/a-/AN66SAx_IKwJUXeZ3VkHQ0cG2hgNSgypTx_3A604gQ=s288-mo-c-c0xffffffff-rj-k-no")
		
    Add_Dir( 
        name="[B][COLOR red]Weihnachtsmann & Co Kg[/B][/COLOR]", url=BASE2+YOUTUBE_CHANNEL_ID_11+"/", folder=True,
        icon="https://yt3.ggpht.com/a-/AN66SAwF8apdkY-GSmjONvISQjMqU5dMgMkm0J_jWQ=s288-mo-c-c0xffffffff-rj-k-no")
		
    Add_Dir( 
        name="[B][COLOR orange]Nickelodeon[/B][/COLOR]", url=BASE2+YOUTUBE_CHANNEL_ID_12+"/", folder=True,
        icon="https://yt3.ggpht.com/a-/AN66SAwf5LkubgedaD387H1K5NBoii-fFpAxhM7AWw=s288-mo-c-c0xffffffff-rj-k-no")
		
		
@route(mode='koding_settings')
def Koding_Settings():
    Open_Settings()

@route(mode='simple_dialog', args=['title','msg'])
def Simple_Dialog(title,msg):
    OK_Dialog(title, msg)


if __name__ == "__main__":
    Run(default='main_menu')
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
	
	
	####Litti19928#### 16:40 
	