#!/usr/bin/payhon
# -*- coding: utf-8 -*-
import os,sys,xbmc,xbmcgui,xbmcaddon,xbmcplugin

def __fix_encoding__(path):
	if sys.version_info.major == 2:

		if sys.platform.startswith('win'):return path.decode('utf-8')
		else:return path.decode('utf-8').encode('ISO-8859-1')

	elif sys.version_info.major == 3:return path

__addon__ =  xbmcaddon.Addon()
__addon_path__ = __fix_encoding__(__addon__.getAddonInfo('path'))

def __get_youtube_live_stream__(channel_id):
	return'plugin://plugin.video.youtube/play/?channel_id=%s&live=1' % channel_id

def __get_youtube_video__(video_id):
	return'plugin://plugin.video.youtube/?action=play_video&videoid=%s' % video_id

def __get_youtube_playlist__(playlist_id):
	return'plugin://plugin.video.youtube/playlist/%s/' % playlist_id

def __get_youtube_channel__(channel_id):
	return'plugin://plugin.video.youtube/channel/%s/' % channel_id
    
def __get_youtube_user__(user_id):
	return'plugin://plugin.video.youtube/user/%s/' % user_id

def __get_youtube_search__(search_text):
	return'plugin://plugin.video.youtube/search/?q=%s' % search_text
    
def __add_item__(title,url,image,plot,is_folder=False):
    item=xbmcgui.ListItem(title,path=url)
    item.setInfo(type='Video',infoLabels={'Title':title,'Plot':plot} )
    item.setArt({'icon':image,'poster':image,'banner':image,})
    item.setProperty('IsPlayable','true')
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=item,isFolder=is_folder)
       
def __set_content__(content):
	xbmcplugin.setContent(int(sys.argv[1]),content)
    
def __set_view_mode__(view_mode=''):
	xbmc.executebuiltin('Container.SetViewMode(%s)' % (view_mode))

def __end_of_directory__():
	xbmcplugin.endOfDirectory(handle=int(sys.argv[1]),succeeded=True,updateListing=False,cacheToDisc=False)

    
#----Litti19928----#    
#-------------------#
#__set_view_mode__('50')
__set_content__('movies')
#-------------------#
__add_item__('Masters of Hardcore',__get_youtube_channel__('UCOizSvluYNmho0roIe0rqzg'),os.path.join(__addon_path__,'resources','Hardcore','Masters of Hardcore.jpg'),'Plot ?',is_folder=True)
__add_item__('Angerfist',__get_youtube_user__('TheAngerfistHardcore'),os.path.join(__addon_path__,'resources','Hardcore','Angerfist.jpg'),'Plot ?',is_folder=True)
__add_item__('Miss K8',__get_youtube_user__('MissK8music'),os.path.join(__addon_path__,'resources','Hardcore','Miss K8.jpg'),'Plot ?',is_folder=True)
__add_item__('Dominator',__get_youtube_user__('dominatorfestival'),os.path.join(__addon_path__,'resources','Hardcore','Dominator.jpg'),'Plot ?',is_folder=True)
__add_item__('Q-dance',__get_youtube_user__('Qdancedotnl'),os.path.join(__addon_path__,'resources','Hardcore','Q-dance.jpg'),'Plot ?',is_folder=True)
__add_item__('Korsakoff',__get_youtube_user__('OfficialKorsakoff'),os.path.join(__addon_path__,'resources','Hardcore','Korsakoff.jpg'),'Plot ?',is_folder=True)
__add_item__('Dr.Peacock',__get_youtube_channel__('UCsq3H3cTxvDU1Mktk1DQVkA'),os.path.join(__addon_path__,'resources','Hardcore','Dr. Peacock.jpg'),'Plot ?',is_folder=True)
__add_item__('Peacock Records',__get_youtube_user__('DrPeacockRecords'),os.path.join(__addon_path__,'resources','Hardcore','PeacockRecords.jpg'),'Plot ?',is_folder=True)
__add_item__('SYNDICATE',__get_youtube_channel__('UCzC3Y3ogRVNQoYFysKeirag'),os.path.join(__addon_path__,'resources','Hardcore','SYNDICATE.jpg'),'Plot ?',is_folder=True)
__add_item__('Ruhr-in-Love',__get_youtube_user__('ruhrinloveofficial'),os.path.join(__addon_path__,'resources','Hardcore','Ruhr-in-Love.jpg'),'Plot ?',is_folder=True)
__add_item__('Hardcore Italia',__get_youtube_channel__('UChwhSCeji2XWFUQ4w5l72tw'),os.path.join(__addon_path__,'resources','Hardcore','Hardcore Italia.jpg'),'Plot ?',is_folder=True)
__add_item__('Frenchcore Hardcore',__get_youtube_channel__('UC5Rn3fL-fRgGDKlMxLpyoQg'),os.path.join(__addon_path__,'resources','Hardcore','Frenchcore Hardcore.jpg'),'Plot ?',is_folder=True)
#-------------------#
__end_of_directory__()
