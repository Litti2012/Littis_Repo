# -*- coding: iso-8859-1 -*-
""" The crypto.hash package.
    Part of the CryptoPy framework.
"""   
