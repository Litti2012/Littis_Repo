#!/usr/bin/payhon
# -*- coding: utf-8 -*-
import os,sys,xbmc,xbmcgui,xbmcaddon,xbmcplugin

def fix_encoding(path):
	if sys.platform.startswith('win'):return unicode(path,'utf-8')
	else:return unicode(path,'utf-8').encode('ISO-8859-1')
    
addon_path = fix_encoding(xbmcaddon.Addon().getAddonInfo('path'))

def get_youtube_live_stream(channel_id):
	return'plugin://plugin.video.youtube/play/?channel_id=%s&live=1' % channel_id

def get_youtube_video(video_id):
	return'plugin://plugin.video.youtube/?action=play_video&videoid=%s' % video_id

def get_youtube_playlist(playlist_id):
	return'plugin://plugin.video.youtube/playlist/%s/' % playlist_id

def get_youtube_channel(channel_id):
	return'plugin://plugin.video.youtube/channel/%s/' % channel_id
    
def get_youtube_user(user_id):
	return'plugin://plugin.video.youtube/user/%s/' % user_id

def get_youtube_search(search_text):
	return'plugin://plugin.video.youtube/search/?q=%s' % search_text
    
def add_item(title,url,icon,plot,is_folder=False):
	item=xbmcgui.ListItem(title,iconImage=icon,thumbnailImage=icon)
	item.setInfo(type='Video',infoLabels={'Title':title,'Plot':plot} )
	item.setProperty('IsPlayable','true')
	xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=item,isFolder=is_folder)
       
def set_content(content):
	xbmcplugin.setContent(int(sys.argv[1]),content)
    
def set_view_mode(view_mode=''):
	xbmc.executebuiltin('Container.SetViewMode(%s)' % (view_mode))

def set_end_of_directory(succeeded=True,updateListing=False,cacheToDisc=False):
	xbmcplugin.endOfDirectory(handle=int(sys.argv[1]),succeeded=succeeded,updateListing=updateListing,cacheToDisc=cacheToDisc)

    
#----Litti19928----#    
#-------------------#
#set_view_mode('50')
set_content('video')
#-------------------#
add_item('Masters of Hardcore',get_youtube_channel('UCOizSvluYNmho0roIe0rqzg'),os.path.join(addon_path,'resources','Hardcore','Masters of Hardcore.jpg'),'Plot ?',is_folder=True)
add_item('Angerfist',get_youtube_user('TheAngerfistHardcore'),os.path.join(addon_path,'resources','Hardcore','Angerfist.jpg'),'Plot ?',is_folder=True)
add_item('Miss K8',get_youtube_user('MissK8music'),os.path.join(addon_path,'resources','Hardcore','Miss K8.jpg'),'Plot ?',is_folder=True)
add_item('Dominator',get_youtube_user('dominatorfestival'),os.path.join(addon_path,'resources','Hardcore','Dominator.jpg'),'Plot ?',is_folder=True)
add_item('Q-dance',get_youtube_user('Qdancedotnl'),os.path.join(addon_path,'resources','Hardcore','Q-dance.jpg'),'Plot ?',is_folder=True)
add_item('Korsakoff',get_youtube_user('OfficialKorsakoff'),os.path.join(addon_path,'resources','Hardcore','Korsakoff.jpg'),'Plot ?',is_folder=True)
add_item('Dr.Peacock',get_youtube_channel('UCsq3H3cTxvDU1Mktk1DQVkA'),os.path.join(addon_path,'resources','Hardcore','Dr. Peacock.jpg'),'Plot ?',is_folder=True)
add_item('Peacock Records',get_youtube_user('DrPeacockRecords'),os.path.join(addon_path,'resources','Hardcore','PeacockRecords.jpg'),'Plot ?',is_folder=True)
add_item('SYNDICATE',get_youtube_channel('UCzC3Y3ogRVNQoYFysKeirag'),os.path.join(addon_path,'resources','Hardcore','SYNDICATE.jpg'),'Plot ?',is_folder=True)
add_item('Ruhr-in-Love',get_youtube_user('ruhrinloveofficial'),os.path.join(addon_path,'resources','Hardcore','Ruhr-in-Love.jpg'),'Plot ?',is_folder=True)
add_item('Hardcore Italia',get_youtube_channel('UChwhSCeji2XWFUQ4w5l72tw'),os.path.join(addon_path,'resources','Hardcore','Hardcore Italia.jpg'),'Plot ?',is_folder=True)
add_item('Frenchcore Hardcore',get_youtube_channel('UC5Rn3fL-fRgGDKlMxLpyoQg'),os.path.join(addon_path,'resources','Hardcore','Frenchcore Hardcore.jpg'),'Plot ?',is_folder=True)
#-------------------#
set_end_of_directory()