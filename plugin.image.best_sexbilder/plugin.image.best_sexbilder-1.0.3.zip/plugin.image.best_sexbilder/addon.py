#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmc,xbmcplugin,xbmcaddon,xbmcgui,os,sys,urllib,urllib2,re
xbmcplugin.setContent(int(sys.argv[1]),'Picture')
addon = xbmcaddon.Addon()
addon_path = addon.getAddonInfo('path').decode('utf-8')
def requesthandler(url,security_headers=None):
    try:
        opener = urllib2.build_opener()
        opener.addheaders = [('User-Agent','Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36'),('Accept-Language','fr-CH, fr;q=0.9, en;q=0.8, de;q=0.7, *;q=0.5'),('Accept','text/html, application/xhtml+xml, application/xml;q=0.9')]
        if not security_headers == None:
            opener.addheaders = security_headers
        response = opener.open(url,timeout=20)
        r = response.read()
        response.close()
        return r
    except:
        return ''
def addDir(name,url,mode,iconimage):
    u=sys.argv[0]+'?url='+urllib.quote_plus(url)+'&mode='+str(mode)+'&name='+urllib.quote_plus(name)+'&iconimage='+urllib.quote_plus(iconimage)
    liz=xbmcgui.ListItem(name, iconImage='DefaultFolder.png', thumbnailImage=iconimage)
    liz.setInfo( type='Picture', infoLabels={ 'Title': name } )
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
def addItem(url, infolabels, img):
    listitem = xbmcgui.ListItem(infolabels['title'], iconImage=img, thumbnailImage=img)
    listitem.setInfo('Picture', infolabels)
    listitem.setProperty('IsPlayable','false')
    xbmcplugin.addDirectoryItem(int(sys.argv[1]), url, listitem)	
def get_nav_bar(content):
    match = re.search('<ul[^<>]*class="nav navbar-nav"[^<>]*>[\s\S]*?<\/ul>', content,re.DOTALL)
    if match:
        return match.group(0)
def get_nav_bar_data(content):
    for url,name in re.findall('<li><a href="(.*?)">(.*?)<\/a><\/li>',content,re.DOTALL):
        addDir(name.upper(),'http://besten-sexbilder.com' + url,1,os.path.join(addon_path,'folder.png'))
def get_row_portfolio(content):
    match = re.search('<div[^<>]*class="row portfolio"[^<>]*>[\s\S]*<div class="clear">', content,re.DOTALL)
    if match:
        return match.group(0)
def get_row_portfolio_data(content):
    for url,image,title in re.findall("href='(.*?)'.*?src='(.*?)'.*?alt='(.*?)'",content,re.DOTALL):
        addDir(title,'http://besten-sexbilder.com' + url,2,image)
def get_image_gallery(content):
    match = re.search('<ul[^<>]*id="image-gallery"[^<>]*>[\s\S]*?<\/ul>', content,re.DOTALL)
    if match:
        return match.group(0)
def get_image_gallery_data(content,name):
    for image in re.findall("src='(.*?)'",content,re.DOTALL):
        addItem(image,{'title':'[COLOR red]'+name+'[/COLOR]'},image)
def get_next_page(content):
    match = re.search('''<div[^<>]*class="col-md-12 text-center"[\s\S]*<a href='(.*?)' style='font-size:20px;padding-left: 15px;'>Nächsten >><\/a>''', content,re.DOTALL) # https://regex101.com/r/peawuc/2
    if match:
        addDir('NEXT >>','http://besten-sexbilder.com' + str(match.group(1)),1,os.path.join(addon_path,'next.png'))
def get_params():
    param=[]
    paramstring=sys.argv[2]
    if len(paramstring)>=2:
        params=sys.argv[2]
        cleanedparams=params.replace('?','')
        if (params[len(params)-1]=='/'):
            params=params[0:len(params)-2]
        pairsofparams=cleanedparams.split('&')
        param={}
        for i in range(len(pairsofparams)):
            splitparams={}
            splitparams=pairsofparams[i].split('=')
            if (len(splitparams))==2:
                param[splitparams[0]]=splitparams[1]                         
        return param		
params=get_params()
url=None
name=None
mode=None
iconimage=None
try:
    url=urllib.unquote_plus(params["url"])
except:
    pass
try:
    name=urllib.unquote_plus(params["name"])
except:
    pass
try:
    iconimage=urllib.unquote_plus(params["iconimage"])
except:
    pass
try:        
    mode=int(params["mode"])
except:
    pass
if mode == None: 
    get_nav_bar_data(get_nav_bar(requesthandler('http://besten-sexbilder.com/sexfotos.php')))
if mode == 1:
    r = requesthandler(url)
    get_row_portfolio_data(get_row_portfolio(r))
    addDir('BASE','',4,os.path.join(addon_path,'icon.png'))
    get_next_page(r)
if mode == 2:
    get_image_gallery_data(get_image_gallery(requesthandler(url)),name)
if mode == 3:
    get_image_gallery_data(get_image_gallery(requesthandler(url)),name)
if mode == 4:
    get_nav_bar_data(get_nav_bar(requesthandler('http://besten-sexbilder.com/sexfotos.php')))
xbmcplugin.endOfDirectory(int(sys.argv[1]))