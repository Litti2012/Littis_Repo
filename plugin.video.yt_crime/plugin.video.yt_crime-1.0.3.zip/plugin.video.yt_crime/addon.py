#!/usr/bin/python
# -*- coding: utf-8 -*-
import os,sys
import xbmc,xbmcgui,xbmcaddon,xbmcplugin

def fix_encoding(path):
	if sys.platform.startswith('win'):return unicode(path,'utf-8')
	else:return unicode(path,'utf-8').encode('ISO-8859-1')

addon_path = fix_encoding(xbmcaddon.Addon().getAddonInfo('path'))

def set_content(content):
	xbmcplugin.setContent(int(sys.argv[1]),content)

def set_view_mode(view_mode):
    xbmc.executebuiltin('Container.SetViewMode(%s)' % (view_mode))

def set_end_of_directory(succeeded=True,updateListing=False,cacheToDisc=False):
	xbmcplugin.endOfDirectory(handle=int(sys.argv[1]),succeeded=True,updateListing=False,cacheToDisc=False)

def get_youtube_live_stream(channel_id):# is_folder_bool=False
	return'plugin://plugin.video.youtube/play/?channel_id=%s&live=1' % channel_id

def get_youtube_video(video_id):# is_folder_bool=False
	return'plugin://plugin.video.youtube/?action=play_video&videoid=%s' % video_id

def get_youtube_playlist(playlist_id):# is_folder_bool=True
	return'plugin://plugin.video.youtube/playlist/%s/' % playlist_id

def get_youtube_channel(channel_id):# is_folder_bool=True
	return'plugin://plugin.video.youtube/channel/%s/' % channel_id

def add_item(title,url,icon,plot,is_folder=False):
	item=xbmcgui.ListItem(title,iconImage=icon,thumbnailImage=icon)
	item.setInfo(type='Video',infoLabels={'Title':title,'Plot':plot} )
	item.setProperty('IsPlayable','true')
	xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=item,isFolder=is_folder)

#-------------------#
#set_view_mode('50')
set_content('movies')
#-----------------------------------------------------------------------------------------------#


add_item('Crime Serien',get_youtube_playlist('PLwEQPdLQtJDXz7Na2XI6V2Fn6s5EbNbnf'),os.path.join(addon_path,'resources','icons','test.jpg'),'Crime Serien Über 700 Folgen RTL Crime und viele mehr.',is_folder=True)
add_item('Crime Doku Serien',get_youtube_playlist('PL8vy1Dmnedmpjwe51g22ts-GjhKYeqnL1'),os.path.join(addon_path,'resources','icons','test.jpg'),'Über 1000 Folgen an Crime Doku Serien.',is_folder=True)
add_item('Crime Nitro',get_youtube_playlist('PL6qgzmhUOdcSKX-sOkFqK5dPru0NesiLy'),os.path.join(addon_path,'resources','icons','test.jpg'),'Über 800 Folgen Crime Nitro.',is_folder=True)
add_item('Dokus Kriminalfälle',get_youtube_playlist('PLD9tXDfn3aaOiQsMHzpPQK3fVBtYqo5Hl'),os.path.join(addon_path,'resources','icons','test.jpg'),'Über 1900 Crime Folgen.',is_folder=True)
add_item('Medical Detectives',get_youtube_playlist('PLmDMqOFEP4we-ndSesMUYM_sqQG5rHPrx'),os.path.join(addon_path,'resources','icons','test.jpg'),'190 Folgen der Beliebten Crime Serie Medical Detectivs',is_folder=True)
add_item('Evil Gesichter des Bösen Duko',get_youtube_playlist('PLwwYB1SxNboc5PnpjEz4EioRSlAQ_5UXC'),os.path.join(addon_path,'resources','icons','test.jpg'),'Über 200 Folgen Evil Gesichter des Bösen. ',is_folder=True)
add_item('True Crime Shows',get_youtube_playlist('PL-t786AQxGO_7Rt3_4O01qKZXm6D-G-Od'),os.path.join(addon_path,'resources','icons','test.jpg'),'True Crime Shows über 900 Folgen.',is_folder=True)
add_item('Tot ist Tot',get_youtube_playlist('PLDcqbMdsxhwAFxkfbxzUPbOaTZMaH7sur'),os.path.join(addon_path,'resources','icons','test.jpg'),'Tot ist Tot mit über 500 Folgen über Forensiker und ihre arbeit.',is_folder=True)
add_item('Crime,Mord,Verbrechen,Forensik',get_youtube_playlist('PL834000BB679DB7D1'),os.path.join(addon_path,'resources','icons','test.jpg'),'Dokus und Crime Serien 550 und mehr Folgen.',is_folder=True)
add_item('Crime Dokus',get_youtube_playlist('PLw0DvFGknEqxvXjh5kXJwLO6f1sVrjzRa'),os.path.join(addon_path,'resources','icons','test.jpg'),'Crime Serien und Dokus mehr als 1000 Folgen.',is_folder=True)
add_item('TLC Crime',get_youtube_playlist('PLl8ibJeajPL3FNXyS80DvArkr6rL9gZvH'),os.path.join(addon_path,'resources','icons','test.jpg'),'190 Folgen Crime vom Sender TLC.',is_folder=True)
add_item('Todsünden - Deadly Sins',get_youtube_playlist('PLt1hN3KlMBq3hhcCW4a4vWFrv6ebTQ23K'),os.path.join(addon_path,'resources','icons','test.jpg'),'In „Deadly Sins“ führt Andrea Sawatzki durch reale Kriminalfälle aus den USA, die in aufwendigen Szenen nachgespielt wurden. Angehörige, Ermittler und andere Beteiligte erzählen aus erster Hand, wie es zu diesen grausamen Taten kommen konnte. Männer, die ihre schwangeren Frauen eiskalt ermorden oder Menschen, die scheinbar nur aus Langeweile morden. Alle Täter sind getrieben von den dunkelsten menschlichen Instinkten.',is_folder=True)
add_item('Crime Doku Sammlungen',get_youtube_playlist('PL8vy1Dmnedmpjwe51g22ts-GjhKYeqnL1'),os.path.join(addon_path,'resources','icons','test.jpg'),'Crime,Dous und mehr über 1000 Folgen.',is_folder=True)




	
#-----------------------------------------------------------------------------------------------#

set_end_of_directory()