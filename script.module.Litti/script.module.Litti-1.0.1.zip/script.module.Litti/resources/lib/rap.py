#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmc,xbmcgui,xbmcaddon,xbmcplugin,os,sys,urllib



def fix_encoding(path):
	if sys.platform.startswith('win'):return unicode(path,'utf-8')
	else:return unicode(path,'utf-8').encode('ISO-8859-1')

addon_path = fix_encoding(xbmcaddon.Addon().getAddonInfo('path'))

def update_addon():
	xbmc.executebuiltin('UpdateLocalAddon')


def test_viewer(s):
    import xbmcgui
    xbmcgui.Dialog().textviewer('TEST VIEWER', str(s))

def set_content(content):
	xbmcplugin.setContent(int(sys.argv[1]),content)
	
def set_view_mode(view_mode):
    xbmc.executebuiltin('Container.SetViewMode(%s)' % (view_mode))
	
def set_end_of_directory(succeeded=True,updateListing=False,cacheToDisc=False):
	xbmcplugin.endOfDirectory(handle=int(sys.argv[1]),succeeded=True,updateListing=False,cacheToDisc=False)
	
def get_youtube_live_stream(channel_id):
	return'plugin://plugin.video.youtube/play/?channel_id=%s&live=1' % channel_id

def get_youtube_video(video_id):
	return'plugin://plugin.video.youtube/?action=play_video&videoid=%s' % video_id

def get_youtube_playlist(playlist_id):
	return'plugin://plugin.video.youtube/playlist/%s/' % playlist_id

def get_youtube_channel(channel_id):
	return'plugin://plugin.video.youtube/channel/%s/' % channel_id

def get_youtube_search(search_text):
	return'plugin://plugin.video.youtube/search/?q=%s' % search_text

def get_youtube_user(user_id):
	return'plugin://plugin.video.youtube/user/%s/' % user_id



def add_item(title,url,icon,plot,is_folder=False):
	item=xbmcgui.ListItem(title,iconImage=icon,thumbnailImage=icon)
	item.setInfo(type='Video',infoLabels={'Title':title,'Plot':plot} )
	item.setProperty('IsPlayable','true')
	xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=item,isFolder=is_folder)

def add_dir(title,url,icon,plot,mode,is_folder=True):
	url=sys.argv[0]+'?title='+urllib.quote_plus(title)+'&url='+urllib.quote_plus(url)+'&Image='+urllib.quote_plus(icon)+'&mode='+str(mode)
	item=xbmcgui.ListItem(title,iconImage=icon,thumbnailImage=icon)
	item.setInfo( type='Video', infoLabels={'Title':title ,'Plot':plot})
	xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=item,isFolder=is_folder)
    
def get_params():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?', '')
        if params[len(params) - 1] == '/':
            params = params[0:len(params) - 2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if len(splitparams) == 2:
                param[splitparams[0]] = splitparams[1]

        return param
params = get_params()

title = None
try:title = urllib.unquote_plus(params['title'])
except:pass

url = None
try:url = urllib.unquote_plus(params['url'])
except:pass

image = None
try:image = urllib.unquote_plus(params['image'])
except:pass

mode = None
try:mode = int(params['mode'])
except:pass


if mode == None:
  add_dir('Deutscher Hip Hop','',os.path.join(addon_path,'resources','Deutscher Hip Hop icons','Deutscher Hip Hop.png'),'[B][COLOR red]Deutscher Hip Hop Channel[/B][/COLOR]',1)
  add_dir('Deutschrap Update','',os.path.join(addon_path,'resources','Deutscher Hip Hop icons','Deutschrap-Update.png'),'[B][COLOR red]Deutschrap-Update[/B][/COLOR]',2)
  #add_dir('Test 3','',os.path.join(addon_path,'resources','icons','test.jpg'),'DEINE INFO - PLOT ?',3)

elif mode == 1:
    add_item('BangerChannel',get_youtube_channel('UCbDNCzgdLlvYY9dk5M8063A'),os.path.join(addon_path,'resources','icons','BangerChannel.jpg'),'Plot ?',is_folder=True)
    add_item('ALPHA MUSIC EMPIRE',get_youtube_channel('UCzmO7GegLke-jb5uZSQ9_HA'),os.path.join(addon_path,'resources','icons','ALPHA MUSIC EMPIRE.jpg'),'Plot ?',is_folder=True)
    add_item('Sido',get_youtube_user('officialsidomusik'),os.path.join(addon_path,'resources','icons','Sido.jpg'),'Plot ?',is_folder=True)
    add_item('Kool Savas',get_youtube_user('EssahTV'),os.path.join(addon_path,'resources','icons','Kool Savas.jpg'),'Plot ?',is_folder=True)
    add_item('CrhymeTV',get_youtube_channel('UCGh8tmH9x9njaI2mXfh2fyg'),os.path.join(addon_path,'resources','icons','CrhymeTV.jpg'),'Plot ?',is_folder=True)
    add_item('Luciano',get_youtube_channel('UCVWm9bTQLmMwHI0To5zQFGA'),os.path.join(addon_path,'resources','icons','luciano.jpg'),'Plot ?',is_folder=True)
    add_item('Kollegah',get_youtube_channel('UCLmyWpIwbKr6HJQ_teYCkVw'),os.path.join(addon_path,'resources','icons','Kollegah.jpg'),'Plot ?',is_folder=True)
    add_item('Capital Bra',get_youtube_channel('UCeJIbOka3ZF8TSWT_-kHmSA'),os.path.join(addon_path,'resources','icons','Capital Bra.jpg'),'Plot ?',is_folder=True)
    add_item('Bausa',get_youtube_channel('UCJl-cGDSoGlB86vB_3scwAQ'),os.path.join(addon_path,'resources','icons','Bausashaus.jpg'),'Plot ?',is_folder=True)
    add_item('Kontra K',get_youtube_channel('UCIgCb1dYprH140Ds0mgeAUA'),os.path.join(addon_path,'resources','icons','Kontra K.jpg'),'Plot ?',is_folder=True)
    add_item('Stay High Ufo361',get_youtube_channel('UCXK2490SNd8EOm84Es6USjw'),os.path.join(addon_path,'resources','icons','Stay High.jpg'),'Plot ?',is_folder=True)
    add_item('SLS MUSIC',get_youtube_channel('UCxIc_NmsGMv4AsTo-mV4Hdg'),os.path.join(addon_path,'resources','icons','SLS MUSIC.jpg'),'Plot ?',is_folder=True)
    add_item('Massiv',get_youtube_channel('UCejUnAtmIGNyh4byycOI-Ww'),os.path.join(addon_path,'resources','icons','Massiv.jpg'),'Plot ?',is_folder=True)
    add_item('Selfmade Records',get_youtube_channel('UCDzpxJB1oNEg7a2Np14TEMQ'),os.path.join(addon_path,'resources','icons','Selfmade Records.jpg'),'Plot ?',is_folder=True)
    add_item('385idéal',get_youtube_channel('UCvnCXuh_zhm75EJ89qJ95Kw'),os.path.join(addon_path,'resources','icons','385ideal.jpg'),'Plot ?',is_folder=True)
    add_item('KC Rebell',get_youtube_channel('UCjdfpszupX-_8TNvVTyoD-Q'),os.path.join(addon_path,'resources','icons','KC Rebell.jpg'),'Plot ?',is_folder=True)
    add_item('SoulForce Records',get_youtube_channel('UCzVu1R27dBESV7ewkkeCpXg'),os.path.join(addon_path,'resources','icons','SoulForce Records.jpg'),'Plot ?',is_folder=True)
    add_item('Azzlackz',get_youtube_channel('UCnH4k3ASwytYAgfsW83OvTg'),os.path.join(addon_path,'resources','icons','Azzlackz.jpg'),'Plot ?',is_folder=True)
    add_item('Milonair TV',get_youtube_channel('UCTJnlbVh-5ONLDbyOOA-fVw'),os.path.join(addon_path,'resources','icons','Milonair TV.jpg'),'Plot ?',is_folder=True)
    add_item('WORLD WIDE RAP[',get_youtube_channel('UCy2i0-VfEbcnv-8-CyF8axw'),os.path.join(addon_path,'resources','icons','WORLD WIDE RAP.jpg'),'Plot ?',is_folder=True)
    add_item('TEAM KUKU',get_youtube_channel('UCGU9EqK5V5m141sNPCOfRBg'),os.path.join(addon_path,'resources','icons','TEAM KUKU.jpg'),'Plot ?',is_folder=True)
    add_item('Fard',get_youtube_channel('UCU920m2cTElVE62gZ84iqrQ'),os.path.join(addon_path,'resources','icons','Fard.jpg'),'Plot ?',is_folder=True)
    add_item('Manuellsen',get_youtube_channel('UCTDTPAm7hgy25Xklg9Yf7eQ'),os.path.join(addon_path,'resources','icons','Manuellsen.jpg'),'Plot ?',is_folder=True)
    add_item('AK AUSSERKONTROLLE',get_youtube_channel('UCNNerW9VaDLNaoT-QO_rRgw'),os.path.join(addon_path,'resources','icons','AK AUSSERKONTROLLE.jpg'),'Plot ?',is_folder=True)
    add_item('LifeisPainTv',get_youtube_channel('UCAbiUl42boUt6vUL019r9Bw'),os.path.join(addon_path,'resources','icons','LifeisPainTv.jpg'),'Plot ?',is_folder=True)
    add_item('Life Is Battle Area',get_youtube_channel('UCzPE_f8K8RzpG9nemUkQEsQ'),os.path.join(addon_path,'resources','icons','Life Is Battle Area.jpg'),'Plot ?',is_folder=True)
    add_item('RAF Camora',get_youtube_channel('UChqcJ_MhP9a4bXy1jQ0QPzQ'),os.path.join(addon_path,'resources','icons','RAF Camora.jpg'),'Plot ?',is_folder=True)
    add_item('Qualitäter Music',get_youtube_channel('UCL6QS1qyZ_nnB62dyZIAT7A'),os.path.join(addon_path,'resources','icons','Qualitater Music.jpg'),'Plot ?',is_folder=True)
    add_item('KOREE',get_youtube_channel('UCLyRHlyYSKZnyOunfBwfp5g'),os.path.join(addon_path,'resources','icons','KOREE.jpg'),'Plot ?',is_folder=True)
    add_item('FettC',get_youtube_channel('UC62xPDaMST7-AwerR_vxdmg'),os.path.join(addon_path,'resources','icons','FettC.jpg'),'Plot ?',is_folder=True)
    add_item('ALLES ODER NIX RECORDS',get_youtube_channel('UCqbKhBvxM3qWzC8huPiifYg'),os.path.join(addon_path,'resources','icons','ALLES ODER NIX RECORDS.jpg'),'Plot ?',is_folder=True)
    add_item('K.I.Z',get_youtube_channel('UCy9Nbtsu7QzefrNsT9nYkzQ'),os.path.join(addon_path,'resources','icons','kiz.jpg'),'Plot ?',is_folder=True)
    add_item('mosh36',get_youtube_channel('UChiDPcLh7uVeGXgkk3ik_ZA'),os.path.join(addon_path,'resources','icons','mosh36TV.jpg'),'Plot ?',is_folder=True)
    add_item('BUY OR DIE - RECORDS',get_youtube_channel('UCbiNa0pLPy2twNkyRzy9Aig'),os.path.join(addon_path,'resources','icons','BUY OR DIE - RECORDS.jpg'),'Plot ?',is_folder=True)
    add_item('Favorite',get_youtube_channel('UCYzGvEIKJ-pzX9XgKfDJGLw'),os.path.join(addon_path,'resources','icons','Favorite.jpg'),'Plot ?',is_folder=True)
    
elif mode == 2:
    add_item('Rap Check',get_youtube_user('GangstaRapLeopard'),os.path.join(addon_path,'resources','icons','Rap Check.jpg'),'Plot ?',is_folder=True)
    add_item('TV Strassensound',get_youtube_user('TVstrassensound'),os.path.join(addon_path,'resources','icons','TV Strassensound.jpg'),'Plot ?',is_folder=True)
    add_item('16BARS',get_youtube_user('www16barsde'),os.path.join(addon_path,'resources','icons','16BARS.jpg'),'Plot ?',is_folder=True)



#-------------------#
#set_view_mode('50')
set_content('movies')
set_end_of_directory()
update_addon()