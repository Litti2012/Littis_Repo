#!/usr/bin/python
# -*- coding: utf-8 -*-
import os,sys,urllib
import xbmc,xbmcaddon,xbmcgui,xbmcplugin

def fix_encoding(path):
	if sys.platform.startswith('win'):return unicode(path,'utf-8')
	else:return unicode(path,'utf-8').encode('ISO-8859-1')
    
addon_path = fix_encoding(xbmcaddon.Addon().getAddonInfo('path'))

def update_addon():
	xbmc.executebuiltin('UpdateLocalAddon')

def test_viewer(s):
    import xbmcgui
    xbmcgui.Dialog().textviewer('TEST VIEWER', str(s))

def set_content(content):
	xbmcplugin.setContent(int(sys.argv[1]),content)
    
def set_view_mode(view_mode):
    xbmc.executebuiltin('Container.SetViewMode(%s)' % (view_mode))
    
def set_end_of_directory(succeeded=True,updateListing=False,cacheToDisc=False):
	xbmcplugin.endOfDirectory(handle=int(sys.argv[1]),succeeded=True,updateListing=False,cacheToDisc=False)
    
def get_youtube_live_stream(channel_id):
	return'plugin://plugin.video.youtube/play/?channel_id=%s&live=1' % channel_id
    
def get_youtube_video(video_id):
	return'plugin://plugin.video.youtube/play/?video_id=%s' % video_id # or # ''plugin://plugin.video.youtube/?action=play_video&videoid=%s'

def get_youtube_playlist(playlist_id):
	return'plugin://plugin.video.youtube/playlist/%s/' % playlist_id
    
def get_youtube_channel(channel_id):
	return'plugin://plugin.video.youtube/channel/%s/' % channel_id
    
def get_youtube_info(info_id):
	return'plugin://plugin.video.youtube/info/%s/' % info_id
    
def get_youtube_user(user_id):
	return'plugin://plugin.video.youtube/user/%s/' % user_id
    
def get_youtube_search(search_text):
	return'plugin://plugin.video.youtube/search/?q=%s' % search_text
    
def add_item(title,url,icon,plot,is_folder=False):
	item=xbmcgui.ListItem(title,iconImage=icon,thumbnailImage=icon)
	item.setInfo(type='Video''audio',infoLabels={'Title':title,'Plot':plot} )
	item.setProperty('IsPlayable','true')
	xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=item,isFolder=is_folder) 
    
    
def add_dir(title,url,icon,plot,mode,is_folder=True):
	url=sys.argv[0]+'?title='+urllib.quote_plus(title)+'&url='+urllib.quote_plus(url)+'&Image='+urllib.quote_plus(icon)+'&mode='+str(mode)
	item=xbmcgui.ListItem(title,iconImage=icon,thumbnailImage=icon)
	item.setInfo( type='Video', infoLabels={'Title':title ,'Plot':plot})
	xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=item,isFolder=is_folder)
    
    
def get_params():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?', '')
        if params[len(params) - 1] == '/':
            params = params[0:len(params) - 2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if len(splitparams) == 2:
                param[splitparams[0]] = splitparams[1]

        return param
params = get_params()

title = None
try:title = urllib.unquote_plus(params['title'])
except:pass

url = None
try:url = urllib.unquote_plus(params['url'])
except:pass

image = None
try:image = urllib.unquote_plus(params['image'])
except:pass

mode = None
try:mode = int(params['mode'])
except:pass



if mode == None:
  add_dir('[COLOR red]Germany Channel[/COLOR]','',os.path.join(addon_path,'resources','Germany','Germany.png'),'DEINE INFO - PLOT ?',1)
  add_dir('[COLOR skyblue]Russland Channel[/COLOR]','',os.path.join(addon_path,'resources','Russia','Russia.jpg'),'DEINE INFO - PLOT ?',2)
  add_dir('[COLOR gold]Hörspiel Channel[/COLOR]','',os.path.join(addon_path,'resources','Horspiel','kinder hoerspiel.jpg'),'DEINE INFO - PLOT ?',3)
  add_dir('[COLOR orange]Musik Channel[/COLOR]','',os.path.join(addon_path,'resources','Musik','Musik Kinder.png'),'DEINE INFO - PLOT ?',4)


elif mode == 1:
    add_item('[COLOR red]Mascha und der Bär[/COLOR]',get_youtube_channel('UCA_DdzBmf5yNaxMpVGwZV4g'),os.path.join(addon_path,'resources','Germany','Mascha und der Bar.jpg'),'Plot ?',is_folder=True)
    add_item('[COLOR red]Peppa Pig Auf Deutsch[/COLOR]',get_youtube_channel('UCNclt7O1bO7hz8Mari68neg'),os.path.join(addon_path,'resources','Germany','Peppa Pig Deutsch.jpg'),'Plot ?',is_folder=True)
    add_item('[COLOR red]Ben und Hollys Kleines Königreich[/COLOR]',get_youtube_channel('UCvt1bcwa1UU9MHcrD_PCijQ'),os.path.join(addon_path,'resources','Germany','Ben und Hollys.jpg'),'Plot ?',is_folder=True)
    add_item('[COLOR red]Bibi Blocksberg[/COLOR]',get_youtube_playlist('PLOZg6nrLYB7-EgluZK6CuMBzJtKhvFIAU'),os.path.join(addon_path,'resources','Germany','Bibi-Blocksberg.jpg'),'Plot ?',is_folder=True)
    add_item('[COLOR red]Tom & Jerry 1. Klassik Serie[/COLOR]',get_youtube_playlist('PLwp8m9anCLK3jmItMyLTgfNpM-526z8Cl'),os.path.join(addon_path,'resources','Germany','Tom & Jerry.jpg'),'Plot ?',is_folder=True)
    add_item('[COLOR red]Tom & Jerry 2. Klassik Serie[/COLOR]',get_youtube_playlist('PL2MVdpCy9PxFf_BZJfjTtNuXTBdyu1ig9'),os.path.join(addon_path,'resources','Germany','Tom & Jerry.jpg'),'Plot ?',is_folder=True)
    add_item('[COLOR red]Nickelodeon[/COLOR]',get_youtube_user('nickelodeonoffiziell'),os.path.join(addon_path,'resources','Germany','Nickelodeon.jpg'),'Plot ?',is_folder=True)
    add_item('[COLOR red]Scooby Doo[/COLOR]',get_youtube_playlist('PLJYf0JdTApCqEYfW77tMTtqN-gA65_LPW'),os.path.join(addon_path,'resources','Germany','Scooby Doo.jpg'),'Plot ?',is_folder=True)
    add_item('[COLOR red]Grisu der kleine Drache[/COLOR]',get_youtube_playlist('PLOE3ysCGNx-1kamFgtU8gGwIvuPmI2FEi'),os.path.join(addon_path,'resources','Germany','Grisu der kleine Drache.jpg'),'Plot ?',is_folder=True)
    add_item('[COLOR red]KIKA[/COLOR]',get_youtube_user('meinKiKA'),os.path.join(addon_path,'resources','Germany','kika.jpg'),'Plot ?',is_folder=True)
    add_item('[COLOR red]Löwenzahn TV[/COLOR]',get_youtube_playlist('PL6enpR8MLihFtKNjGYf_1_wNxE0Eh4q1y'),os.path.join(addon_path,'resources','Germany','Lowenzahn TV.jpg'),'Plot ?',is_folder=True)
    add_item('[COLOR red]Toggolino[/COLOR]',get_youtube_user('TOGGOLINOde'),os.path.join(addon_path,'resources','Germany','Toggolino.jpg'),'Plot ?',is_folder=True)
    add_item('[COLOR red]Pink Panther 1. Klassik Serie[/COLOR]',get_youtube_playlist('PL546904B9DC923B31'),os.path.join(addon_path,'resources','Germany','Pink Panther.jpg'),'Plot ?',is_folder=True)
    add_item('[COLOR red]Pink Panther 2. Klassik Serie[/COLOR]',get_youtube_playlist('PL2MVdpCy9PxFMwC6UaXwNOTZMPUxiU6KB'),os.path.join(addon_path,'resources','Germany','Pink Panther.jpg'),'Plot ?',is_folder=True)
    add_item('[COLOR red]Wickie und die starken Männer 1. Klassik Serie[/COLOR]',get_youtube_playlist('PLGP11O3gIZb-CAn5df2AE687pqGLxv2hr'),os.path.join(addon_path,'resources','Germany','Wickie und die starken Manner.jpg'),'Plot ?',is_folder=True)
    add_item('[COLOR red]Wickie und die starken Männer 2. Klassik Serie[/COLOR]',get_youtube_playlist('PLGP11O3gIZb8jsxU_InVjehKgJy1Z1Eyj'),os.path.join(addon_path,'resources','Germany','Wickie und die starken Manner.jpg'),'Plot ?',is_folder=True)
    add_item('[COLOR red]Ladybug und Cat Noir[/COLOR]',get_youtube_channel('UCrhflWJOzMngoxVIvx_GuEA'),os.path.join(addon_path,'resources','Germany','Ladybug und Cat Noir.jpg'),'Plot ?',is_folder=True)
    add_item('[COLOR red]Playmobil[/COLOR]',get_youtube_user('playmobil'),os.path.join(addon_path,'resources','Germany','Playmobil.jpg'),'Plot ?',is_folder=True)
    add_item('[COLOR red]Feuerwehrmann Sam[/COLOR]',get_youtube_channel('UC2JTZJAtJtckj2v0ETYsDHg'),os.path.join(addon_path,'resources','Germany','Feuerwehrmann Sam.jpg'),'Plot ?',is_folder=True)
    add_item('[COLOR red]Enchantimals Deutsch[/COLOR]',get_youtube_channel('UCm6H0-TtxgGI_3UubbCDymQ'),os.path.join(addon_path,'resources','Germany','Enchantimals Deutsch.jpg'),'Plot ?',is_folder=True)
    add_item('[COLOR red]Das Haus der 101 Dalmatiner[/COLOR]',get_youtube_playlist('PLwRo_ZL2Y27RgKL4JpmMb3K79ND47YNeZ'),os.path.join(addon_path,'resources','Germany','Das Haus der 101 Dalmatiner.png'),'Plot ?',is_folder=True)
    add_item('[COLOR red]Cosmo & Wanda[/COLOR]',get_youtube_playlist('PL3EAABF6814D610AE'),os.path.join(addon_path,'resources','Germany','Cosmo & Wanda.jpg'),'Plot ?',is_folder=True)
    add_item('[COLOR red]Kixi - Kinderfilme, Kinderserien, Lehrfilme[/COLOR]',get_youtube_channel('UCF2IFFQyO5gbhvOCObh1WTQ'),os.path.join(addon_path,'resources','Germany','Kixi - Kinderfilme, Kinderserien, Lehrfilme.jpg'),'Plot ?',is_folder=True)
    add_item('[COLOR red]Toonzoom[/COLOR]',get_youtube_channel('UClbwun8jhk2kyhvOptnmL5A'),os.path.join(addon_path,'resources','Germany','Toonzoom.jpg'),'Plot ?',is_folder=True)
    add_item('[COLOR red]WB Kids Deutschland[/COLOR]',get_youtube_channel('UCrev-dqCk0e1ig6HGZVB6Ow'),os.path.join(addon_path,'resources','Germany','WB Kids Deutschland.jpg'),'Plot ?',is_folder=True)
    add_item('[COLOR red]Oggy und die Kakerlaken[/COLOR]',get_youtube_channel('UCwEuCjq11jl47RS_EjqzTMw'),os.path.join(addon_path,'resources','Germany','Oggy und die Kakerlaken.jpg'),'Plot ?',is_folder=True)
    add_item('[COLOR red]Zig und Sharko[/COLOR]',get_youtube_channel('UCNv_unt8WPc41OCtc_6gUTA'),os.path.join(addon_path,'resources','Germany','Zig und Sharko.jpg'),'Plot ?',is_folder=True)
    add_item('[COLOR red]Die Daltons[/COLOR]',get_youtube_channel('UCHrRic-eeb8241kkL3GbKNg'),os.path.join(addon_path,'resources','Germany','Die Daltons.jpg'),'Plot ?',is_folder=True)


elif mode == 2:
    add_item('[COLOR skyblue]Маша и Медведь [/COLOR]',get_youtube_channel('UCRv76wLBC73jiP7LX4C3l8Q'),os.path.join(addon_path,'resources','Russia','Mascha und der Bar.jpg'),'Plot ?',is_folder=True)
    add_item('[COLOR skyblue]TaDaBoom песенки для детей[/COLOR]',get_youtube_channel('UCYdtrIg2mfi8KkfNQUmQZoQ'),os.path.join(addon_path,'resources','Russia','TaDaBoom.jpg'),'Plot ?',is_folder=True)
    add_item('[COLOR skyblue]Клео и Кукин[/COLOR]',get_youtube_channel('UCArh_vCIFRMR35dd1HQukvg'),os.path.join(addon_path,'resources','Russia','K.jpg'),'Plot ?',is_folder=True)
    add_item('[COLOR skyblue]Фиксики[/COLOR]',get_youtube_channel('UCs_uv3QyUIQjBoL1Ij5BdlQ'),os.path.join(addon_path,'resources','Russia','fixiki.jpg'),'Plot ?',is_folder=True)
    add_item('[COLOR skyblue]Паровозики из Чаггингтона[/COLOR]',get_youtube_channel('UCIOwKErxRgAWecQrVVax2MA'),os.path.join(addon_path,'resources','Russia','Chugggington.jpg'),'Plot ?',is_folder=True)
    add_item('[COLOR skyblue]Get Movies[/COLOR]',get_youtube_user('getmovies'),os.path.join(addon_path,'resources','Russia','Get Movies.jpg'),'Plot ?',is_folder=True)
    add_item('[COLOR skyblue]Жила-была Царевна[/COLOR]',get_youtube_channel('UC_sl0iB9sVbKmc7YJdQA78w'),os.path.join(addon_path,'resources','Russia','X.jpg'),'Plot ?',is_folder=True)
    add_item('[COLOR skyblue]Теремок Kids[/COLOR]',get_youtube_user('TeremokKids'),os.path.join(addon_path,'resources','Russia','Kids.jpg'),'Plot ?',is_folder=True)
    add_item('[COLOR skyblue]Барбоскины[/COLOR]',get_youtube_channel('UC2el0G8cIcOOdjlHy2KOBkQ'),os.path.join(addon_path,'resources','Russia','barboskiny.jpg'),'Plot ?',is_folder=True)
    add_item('[COLOR skyblue]Царевны[/COLOR]',get_youtube_channel('UCUWktU9yc1kitioCNS-U6hw'),os.path.join(addon_path,'resources','Russia','M.jpg'),'Plot ?',is_folder=True)
    add_item('[COLOR skyblue]Царевны[/COLOR]',get_youtube_user('luntik'),os.path.join(addon_path,'resources','Russia','luntik.jpg'),'Plot ?',is_folder=True)
    add_item('[COLOR skyblue]Три богатыря[/COLOR]',get_youtube_user('TriBogatirya'),os.path.join(addon_path,'resources','Russia','T.jpg'),'Plot ?',is_folder=True)
    add_item('[COLOR skyblue]Nick Jr. Россия[/COLOR]',get_youtube_channel('UCSLZXHSv1aQDNeLN3GX6bew'),os.path.join(addon_path,'resources','Russia','Nick.jr.jpg'),'Plot ?',is_folder=True)
    add_item('[COLOR skyblue]Kids Tv Russia - русский мультфильмы для детей[/COLOR]',get_youtube_user('KidsTvRussia'),os.path.join(addon_path,'resources','Russia','kids tv russia.jpg'),'Plot ?',is_folder=True)
    add_item('[COLOR skyblue]Классные Мультики[/COLOR]',get_youtube_channel('UCekJYjb2Eqkj7dSmpGl9KUA'),os.path.join(addon_path,'resources','Russia','russia2.jpg'),'Plot ?',is_folder=True)
    add_item('[COLOR skyblue]Мультики студии Союзмультфильм[/COLOR]',get_youtube_channel('UCrlFHstLFNA_HsIV7AveNzA'),os.path.join(addon_path,'resources','Russia','my.jpg'),'Plot ?',is_folder=True)
    add_item('[COLOR skyblue]Союзмультфильм [/COLOR]',get_youtube_channel('UCHS2LM1n3f5cyL-ebgkqyLw'),os.path.join(addon_path,'resources','Russia','co.jpg'),'Plot ?',is_folder=True)

elif mode == 3:
    add_item('[COLOR gold]Kiddinx TV[/COLOR]',get_youtube_user('kiddinxentertainment'),os.path.join(addon_path,'resources','Horspiel','Kiddinx TV.jpg'),'Plot ?',is_folder=True)
    add_item('[COLOR gold]Benjamin Blümchen TV[/COLOR]',get_youtube_channel('UCMLzrskqdxJ2Txi13JYw8Lw'),os.path.join(addon_path,'resources','Horspiel','Benjamin Blumchen TV.jpg'),'Plot ?',is_folder=True)
    add_item('[COLOR gold]Bibi & Tina TV[/COLOR]',get_youtube_user('bibiundtinaTV'),os.path.join(addon_path,'resources','Horspiel','Bibi & Tina TV.jpg'),'Plot ?',is_folder=True)
    add_item('[COLOR gold]Die Besten Kinderhörbücher[/COLOR]',get_youtube_channel('UC36vslN_0PXeVI2I5gYVJKw'),os.path.join(addon_path,'resources','Horspiel','die besten.jpg'),'Plot ?',is_folder=True)
    add_item('[COLOR gold]Miraculous[/COLOR]',get_youtube_channel('UCpATtlJx4FCqGho6BsH97_w'),os.path.join(addon_path,'resources','Horspiel','Miraculous.jpg'),'Plot ?',is_folder=True)


elif mode == 4:
    add_item('[COLOR orange]Kinderlieder zum Mitsingen und Bewegen[/COLOR]',get_youtube_channel('UCctbi1Jw2jiVhj2ogdwiFdA'),os.path.join(addon_path,'resources','Musik','Kinderlieder zum Mitsingen und Bewegen.jpg'),'Plot ?',is_folder=True)
    add_item('[COLOR orange]Kinderlieder für Babys und Kleinkinder[/COLOR]',get_youtube_channel('UCNPkyFv-1XPV8ilJ0Pu65Ww'),os.path.join(addon_path,'resources','Musik','Kinderlieder fur Babys und Kleinkinder.jpg'),'Plot ?',is_folder=True)
    add_item('[COLOR orange]Lieder zum Lernen für die Grundschule[/COLOR]',get_youtube_channel('UCupzK67t80o3eW08PJb086w'),os.path.join(addon_path,'resources','Musik','Lieder zum Lernen fur die Grundschule.jpg'),'Plot ?',is_folder=True)
    add_item('[COLOR orange]KIDZ BOP Germany[/COLOR]',get_youtube_channel('UCER41-5KebJp-wbUi068Lew'),os.path.join(addon_path,'resources','Musik','KIDZ BOP Germany.jpg'),'Plot ?',is_folder=True)
    add_item('[COLOR orange]Top 100 Kids Disco Party Songs![/COLOR]',get_youtube_playlist('PLGYPpIsdZKnLRU3hBKDmUBRdzVdM0rS0z'),os.path.join(addon_path,'resources','Musik','Top 100 Kids.jpg'),'Plot ?',is_folder=True)



#set_view_mode('50')
set_content('movies')
set_end_of_directory()
update_addon()