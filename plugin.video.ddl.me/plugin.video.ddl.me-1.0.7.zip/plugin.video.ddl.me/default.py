#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmc,xbmcgui,xbmcplugin,xbmcaddon,urllib,sys,os,re,json,time

try:import resolveurl as urlresolver
except ImportError:import urlresolver

BASE_URL ='https://de.ddl.me'

def fix_encoding(path):
    if sys.platform.startswith('win'):return unicode(path,'utf-8')
    else:return unicode(path,'utf-8').encode('ISO-8859-1')

_addon_ =  xbmcaddon.Addon()
_addon_id_ = _addon_.getAddonInfo('id')
_addon_path_ = fix_encoding(_addon_.getAddonInfo('path'))
_addon_icon_ = fix_encoding(_addon_.getAddonInfo('icon'))

sys.path.append(os.path.join(_addon_path_,'resources','lib'))
import requests
import cfscrape

_player_ = xbmc.Player()
_playlist_ = xbmc.PlayList(0)

def get_request(url,headers_dict=None):
    scraper = cfscrape.create_scraper()
    content = scraper.get(url).content
    scraper.close()
    return content

def add_item(array_dict,is_folder=True,IsPlayable=False,load_playlist=False,context_menu=False):

    index = 0
    if load_playlist == True and len(_playlist_) > 0:_playlist_.clear()

    for dict in array_dict:

        listitem = xbmcgui.ListItem(label=dict['title'],iconImage='DefaultFolder.png',thumbnailImage=dict['image'],path=dict['url'])
        listitem.setInfo(type='video',infoLabels={'Title':dict['title'],'Plot':dict['plot']})
        listitem.setProperty('fanart_image',dict['image'])

        if is_folder == True:url=sys.argv[0]+'?title='+urllib.quote_plus(dict['title'])+'&url='+urllib.quote_plus(dict['url'])+'&image='+urllib.quote_plus(dict['image'])+'&season='+str(dict['season'])+'&episode='+str(dict['episode'])+'&extras='+str(dict['extras'])+'&imode='+str(dict['imode'])
        if is_folder == False:url=dict['url']

        if IsPlayable==True:listitem.setProperty('IsPlayable','true')
        if IsPlayable==False:listitem.setProperty('IsPlayable','false')

        if context_menu == True:
            com = [('[COLOR blue]DOWNLOAD SELECT ITEM[/COLOR]','Xbmc.RunPlugin(%s)' % (sys.argv[0]+'?cmode=1'+'&title='+urllib.quote_plus(dict['title'])+'&url='+urllib.quote_plus(dict['url'])))]
            listitem.addContextMenuItems(items=com,replaceItems=True)

        if load_playlist == True:_playlist_.add(url=dict['url'],listitem=listitem,index=index);index += 1
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=listitem,isFolder=is_folder,totalItems=len(array_dict))

def get_next_page(content):
    array_dict_list=[]
    match = re.compile("<a  class='pnext' href='(.*?)'", re.DOTALL).search(content)
    if match :array_dict_list.append({'title':'[COLOR blue]Next Page[/COLOR]','url':BASE_URL + match.group(1),'image':os.path.join(_addon_path_,'next.png'),'season':'','episode':'','extras':'','plot':'[COLOR blue]Next Page >>>[/COLOR]','imode':4})
    array_dict_list.append({'title':'[COLOR blue]Back to Start[/COLOR]','url':'','image':os.path.join(_addon_path_,'start.png'),'season':'','episode':'','extras':'update','plot':'[COLOR blue]Back to Start[/COLOR]','imode':None})
    xbmcplugin.addSortMethod(int(sys.argv[1]),xbmcplugin.SORT_METHOD_UNSORTED)
    add_item(array_dict_list,is_folder=True,IsPlayable=False,load_playlist=False,context_menu=False)

def get_all_entries(content):
    array_dict_list=[]

    for title,url,img in re.compile("<div class='iwrap[\s\S]*?title='(.*?)'[\s\S]*?href='(.*?)'[\s\S]*?src='(.*?)'", re.DOTALL).findall(content):
        array_dict_list.append({'title':title.strip(),'url':BASE_URL + url,'image':'https:'+img,'season':'','episode':'','extras':title.strip(),'plot':title.strip(),'imode':5})

    xbmcplugin.setContent( int(sys.argv[1]),'files')
    xbmcplugin.addSortMethod(int(sys.argv[1]),xbmcplugin.SORT_METHOD_UNSORTED)
    add_item(array_dict_list,is_folder=True,IsPlayable=False,load_playlist=False,context_menu=False)
    get_next_page(content)

def get_genre_list(content):
    array_dict_list=[]

    match = re.compile('<i[^>]*class="genre.*?<span>Genre<\/span>', re.DOTALL).search(content)
    if match :

        for url,title in re.compile('<a[^>]*href="([^"]+)".*?i>([^<]+)', re.DOTALL).findall(match.group(0)):
            array_dict_list.append({'title':'[COLOR blue]' + title.strip() + '[/COLOR]','url':BASE_URL + url,'image':os.path.join(_addon_path_,'folder.png'),'season':'','episode':'','extras':'','plot':'[COLOR blue]' + title.strip() + '[/COLOR]','imode':4})

        xbmcplugin.setContent( int(sys.argv[1]),'files')
        xbmcplugin.addSortMethod(int(sys.argv[1]),xbmcplugin.SORT_METHOD_UNSORTED)
        add_item(array_dict_list,is_folder=True,IsPlayable=False,load_playlist=False,context_menu=False)

def get_seasons(extra,url,content,img):
    array_dict_list=[]

    match = re.compile('var[ ]subcats[ ]=[ ](.*?);', re.DOTALL).search(content)
    data = json.loads(match.group(1))

    for key, value in data.items():
        seasons_nr = str(value['info']['staffel'])

        if not any(seasons_nr in d.values() for d in array_dict_list):
            array_dict_list.append({'title':'[COLOR blue]Staffel ' + str(seasons_nr) + ' :[/COLOR] ' + extra ,'url':url,'image':img,'season':seasons_nr,'episode':'','extras':extra,'plot':get_plot(content),'imode':6})

    array_dict_list = sorted(array_dict_list)
    xbmcplugin.setContent(int(sys.argv[1]),'movies')
    xbmcplugin.addSortMethod(int(sys.argv[1]),xbmcplugin.SORT_METHOD_LABEL)
    add_item(array_dict_list,is_folder=True,IsPlayable=False,load_playlist=False,context_menu=False)

def get_episodes(url,content,season,img,extra):
    array_dict_list=[]

    match = re.compile('var[ ]subcats[ ]=[ ](.*?);', re.DOTALL).search(content)
    data = json.loads(match.group(1))

    episodes = {}
    for key, value in data.items():
        seasons_nr = str(value['info']['staffel'])

        if seasons_nr not in season:continue
        episode_nr = str(value['info']['nr'])

        if episode_nr not in episodes.keys():
            episodes.update({episode_nr:key})

    for i_episodes_nr, s_episodes_id in episodes.items():

        epi_name = data[s_episodes_id]['info']['name'].encode('utf-8')
        epi_name = epi_name.split("»")[0].strip()

        array_dict_list.append({'title':'[COLOR blue]Episode ' + str(i_episodes_nr) + ' :[/COLOR] ' + epi_name,'url':url,'image':img,'season':i_episodes_nr,'episode':s_episodes_id,'extras':'[COLOR blue]' + extra + ' :[/COLOR] ' + epi_name,'plot':get_plot(content),'imode':5})

    array_dict_list = sorted(array_dict_list)
    xbmcplugin.setContent(int(sys.argv[1]),'movies')
    xbmcplugin.addSortMethod(int(sys.argv[1]),xbmcplugin.SORT_METHOD_LABEL)
    add_item(array_dict_list,is_folder=True,IsPlayable=False,load_playlist=False,context_menu=False)

def search_keyboard():
    search_string = xbmcgui.Dialog().input('[COLOR blue]MP3CO.BIZ SEARCH[/COLOR]', type=xbmcgui.INPUT_ALPHANUM).strip()
    if not search_string == '':
        return urllib.unquote_plus(BASE_URL + '/search_99/?q=' + urllib.quote(search_string) + '/')
    else:sys.exit(0)

def get_plot(content):

    match = re.compile("<p class='detailDesc'>[\s\S]*?'>[\s\S]*?'>(.*?)<br><br>", re.DOTALL).search(content)
    if match:
        if '</i>' in match.group(1):return unicode(match.group(1),'utf-8').split('</i>')[1].strip()
        else:return unicode(match.group(1),'utf-8').strip()

def get_hoster(content,episodes_id,extra,img):
    array_dict_list=[]
    match = re.compile('var[ ]subcats[ ]=[ ](.*?);', re.DOTALL).search(content)
    data = json.loads(match.group(1))

    if not episodes_id:episodes_id = data.keys()[0]
    part_count = 1
    if '1' in data[episodes_id]:part_count = int(data[episodes_id]['1'])

    for hosters in data[episodes_id]['links']:
        for hoster_entry in data[episodes_id]['links'][hosters]:

            stream_url = hoster_entry[3].replace('\/','/')
            source = urlresolver.HostedMediaFile(url=stream_url)
            if not source.valid_url():continue

            if  part_count == 1 :
                array_dict_list.append({'title':'[COLOR red]' + str(hosters) + ' :[/COLOR] ' + extra,'url':stream_url,'image':img,'season':'','episode':'','extras':extra,'plot':get_plot(content),'imode':7})
            if  part_count > 1:
                array_dict_list.append({'title':'[COLOR red]' + str(hosters) + ' Part ' + hoster_entry[0] + ' :[/COLOR] ' + extra,'url':stream_url,'image':img,'season':'','episode':'','extras':extra,'plot':get_plot(content),'imode':7})

    xbmcplugin.setContent(int(sys.argv[1]),'movies')
    xbmcplugin.addSortMethod(int(sys.argv[1]),xbmcplugin.SORT_METHOD_UNSORTED)
    add_item(array_dict_list,is_folder=True,IsPlayable=False,load_playlist=False,context_menu=False)

def get_resolved_url(url):
    try:
        source = urlresolver.HostedMediaFile(url=url)
        if source.valid_url():return source.resolve()
    except Exception as err:xbmcgui.Dialog().notification('Resolver Info !',str(err),_addon_icon_,2000);sys.exit(0)

def play_item(title,url,img):
    if _player_ .isPlaying(): 
        endtime = time.time() + 5
        while _player_ .isPlaying() and time.time() < endtime: _player_ .stop()
    listitem = xbmcgui.ListItem(label=title,iconImage=img,thumbnailImage=img)
    listitem.setInfo(type='video',infoLabels={'Title':title})
    _player_ .play(item=url,listitem=listitem)
    sys.exit(0)

def get_params():
    param=[]
    paramstring=sys.argv[2]
    if len(paramstring)>=2:
        params=sys.argv[2]
        cleanedparams=params.replace('?','')
        if (params[len(params)-1]=='/'):
            params=params[0:len(params)-2]
        pairsofparams=cleanedparams.split('&')
        param={}
        for i in range(len(pairsofparams)):
            splitparams={}
            splitparams=pairsofparams[i].split('=')
            if (len(splitparams))==2:
                param[splitparams[0]]=splitparams[1]                         
        return param		
params=get_params()

title=None
try:title=urllib.unquote_plus(params['title'])
except:pass
url=None
try:url=urllib.unquote_plus(params['url'])
except:pass
image=None
try:image=urllib.unquote_plus(params['image'])
except:pass
season=None
try:season=urllib.unquote_plus(params['season'])
except:pass
episode=None
try:episode=urllib.unquote_plus(params['episode'])
except:pass
extras=None
try:extras=urllib.unquote_plus(params['extras'])
except:pass
imode=None
try:imode=int(params['imode'])
except:pass
index=None
try:index=int(params['index'])
except:pass
cmode=None
try:cmode=int(params['cmode'])
except:pass

if imode == None:
    array_dict_list=[]
    if extras == 'update':xbmc.executebuiltin('XBMC.Container.Update(path,replace)')
    array_dict_list.append({'title':'[COLOR blue]Update[/COLOR]','url':BASE_URL,'image':os.path.join(_addon_path_,'folder.png'),'season':'','episode':'','extras':'','plot':'[COLOR blue]Update[/COLOR]','imode':4})
    array_dict_list.append({'title':'[COLOR blue]Relase[/COLOR]','url':'https://en.ddl.me/releases/alle/cover/','image':os.path.join(_addon_path_,'folder.png'),'season':'','episode':'','extras':'','plot':'[COLOR blue]Relase[/COLOR]','imode':4})
    array_dict_list.append({'title':'[COLOR blue]Filme[/COLOR]','url':'','image':os.path.join(_addon_path_,'folder.png'),'season':'','episode':'','extras':'','plot':'[COLOR blue]Filme[/COLOR]','imode':1})
    array_dict_list.append({'title':'[COLOR blue]Serien[/COLOR]','url':'','image':os.path.join(_addon_path_,'folder.png'),'season':'','episode':'','extras':'','plot':'[COLOR blue]Serien[/COLOR]','imode':2})
    array_dict_list.append({'title':'[COLOR blue]Top 100 Today[/COLOR]','url':'https://en.ddl.me/top100/cover/today/all/','image':os.path.join(_addon_path_,'folder.png'),'season':'','episode':'','extras':'','plot':'[COLOR blue]Top 100 Today[/COLOR]','imode':4})
    array_dict_list.append({'title':'[COLOR blue]Top 100 Month[/COLOR]','url':'https://en.ddl.me/top100/cover/month/all/','image':os.path.join(_addon_path_,'folder.png'),'season':'','episode':'','extras':'','plot':'[COLOR blue]Top 100 Month[/COLOR]','imode':4})
    array_dict_list.append({'title':'[COLOR blue]Top 100 Hall of Fame[/COLOR]','url':'https://en.ddl.me/top100/cover/total/all/','image':os.path.join(_addon_path_,'folder.png'),'season':'','episode':'','extras':'','plot':'[COLOR blue]Top 100 Hall of Fame[/COLOR]','imode':4})
    array_dict_list.append({'title':'[COLOR blue]Suche[/COLOR]','url':'','image':os.path.join(_addon_path_,'search.png'),'season':'','episode':'','extras':'','plot':'[COLOR blue]Suche[/COLOR]','imode':8})
    array_dict_list.append({'title':'[COLOR red][ URLResolver Settings ][/COLOR]','url':'','image':os.path.join(_addon_path_,'resolver.png'),'season':'','episode':'','extras':'','plot':'[COLOR red][ URLResolver Settings ][/COLOR]','imode':9})
    xbmcplugin.setContent( int(sys.argv[1]),'files')
    xbmcplugin.addSortMethod(int(sys.argv[1]),xbmcplugin.SORT_METHOD_UNSORTED)
    add_item(array_dict_list,is_folder=True,IsPlayable=False,load_playlist=False,context_menu=False)

if imode == 1 :
    array_dict_list=[]
    array_dict_list.append({'title':'[COLOR blue]Alle[/COLOR]','url':'https://de.ddl.me/moviez_00_0_1/','image':os.path.join(_addon_path_,'folder.png'),'season':'','episode':'','extras':'','plot':'[COLOR blue]Alle[/COLOR]','imode':4})
    array_dict_list.append({'title':'[COLOR blue]Neue[/COLOR]','url':'https://de.ddl.me/releases/filme/cover/','image':os.path.join(_addon_path_,'folder.png'),'season':'','episode':'','extras':'','plot':'[COLOR blue]Neue[/COLOR]','imode':4})
    array_dict_list.append({'title':'[COLOR blue]Genre[/COLOR]','url':'https://de.ddl.me/moviez_00_0_1_1/','image':os.path.join(_addon_path_,'folder.png'),'season':'','episode':'','extras':'','plot':'[COLOR blue]Genre[/COLOR]','imode':3})
    array_dict_list.append({'title':'[COLOR blue]Back to Start[/COLOR]','url':'','image':os.path.join(_addon_path_,'start.png'),'season':'','episode':'','extras':'update','plot':'[COLOR blue]Back to Start[/COLOR]','imode':None})
    xbmcplugin.setContent( int(sys.argv[1]),'files')
    xbmcplugin.addSortMethod(int(sys.argv[1]),xbmcplugin.SORT_METHOD_UNSORTED)
    add_item(array_dict_list,is_folder=True,IsPlayable=False,load_playlist=False,context_menu=False)

if imode == 2:
    array_dict_list=[]
    array_dict_list.append({'title':'[COLOR blue]Alle[/COLOR]','url':'https://de.ddl.me/episodez_00_0_1_1/','image':os.path.join(_addon_path_,'folder.png'),'season':'','episode':'','extras':'','plot':'[COLOR blue]Alle[/COLOR]','imode':4})
    array_dict_list.append({'title':'[COLOR blue]Neue[/COLOR]','url':'https://de.ddl.me/releases/serien/cover/','image':os.path.join(_addon_path_,'folder.png'),'season':'','episode':'','extras':'','plot':'[COLOR blue]Neue[/COLOR]','imode':4})
    array_dict_list.append({'title':'[COLOR blue]Genre[/COLOR]','url':'https://de.ddl.me/episodez_00_0_1_1/','image':os.path.join(_addon_path_,'folder.png'),'season':'','episode':'','extras':'','plot':'[COLOR blue]Genre[/COLOR]','imode':3})
    array_dict_list.append({'title':'[COLOR blue]Back to Start[/COLOR]','url':'','image':os.path.join(_addon_path_,'start.png'),'season':'','episode':'','extras':'update','plot':'[COLOR blue]Back to Start[/COLOR]','imode':None})
    xbmcplugin.setContent( int(sys.argv[1]),'files')
    xbmcplugin.addSortMethod(int(sys.argv[1]),xbmcplugin.SORT_METHOD_UNSORTED)
    add_item(array_dict_list,is_folder=True,IsPlayable=False,load_playlist=False,context_menu=False)

if imode == 3:
    content = get_request(url)
    get_genre_list(content)

if imode == 4:
    content = get_request(url)
    get_all_entries(content)

if imode == 5:

    content = get_request(url)
    if 'stream-download_0' in url or not episode == None :
        get_hoster(content,episode,extras,image)
    if 'stream-download_1' in url and episode == None:
        get_seasons(extras,url,content,image)

if imode == 6:
    content = get_request(url)
    get_episodes(url,content,season,image,extras)

if imode == 7:
    stream_url = get_resolved_url(url)
    play_item(extras,stream_url,image)

if imode == 8:
    search_url = search_keyboard()
    content = get_request(search_url)
    get_all_entries(content)

if imode == 9:
    urlresolver.display_settings()
    sys.exit(0)

xbmc.executebuiltin('Container.SetViewMode(504)')
xbmcplugin.endOfDirectory(handle=int(sys.argv[1]),succeeded=True,updateListing=False,cacheToDisc=True)