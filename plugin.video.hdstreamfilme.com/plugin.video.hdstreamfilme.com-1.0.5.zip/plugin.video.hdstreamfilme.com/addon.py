#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmc,xbmcgui,xbmcplugin,xbmcaddon
from contextlib import closing
from urlparse import urlparse
import sys,os,urllib,re,time

player_ = xbmc.Player()

import urlresolver
#import resolveurl as urlresolver

BASE_URL = 'https://hdstreamfilme.com'

def fix_encoding(path):
	if sys.platform.startswith('win'):return unicode(path,'utf-8')
	else:return unicode(path,'utf-8').encode('iso-8859-1')

addon_ =  xbmcaddon.Addon()
addon_path_ = fix_encoding(addon_.getAddonInfo('path'))

sys.path.append(os.path.join(addon_path_,'resources','lib'))
import cfscrape

def get_color_text(color,text):
	return '[COLOR '+color+']'+text+'[/COLOR]'

def get_search_keyboard():
	return urllib.quote(xbmcgui.Dialog().input(get_color_text('lime','Search ?'), type=xbmcgui.INPUT_ALPHANUM).strip())

def get_cf_url(url,stream=False,timeout=30,allow_redirects=False,scraper_delay=0,headers_dict={}):
	with closing(cfscrape.create_scraper(scraper_delay)) as scraper:
		return scraper.get(url,stream=stream,timeout=timeout,allow_redirects=allow_redirects,headers=headers_dict)

def add_items(items_array_dict=[['','','','',{},{}]], set_items_type_int=0, set_content_type_int=0, set_params_dict=True, is_folder_bool=True, Is_playable_bool=False):

	item_type_dict ={0:'music',1:'video',2:'pictures',3:'game'}
	content_type_dict={0:'files',1:'songs',2:'artists',3:'albums',4:'movies',5:'tvshows',6:'episodes',7:'musicvideos',8:'videos',9:'images',10:'games'}

	xbmcplugin.setContent(int(sys.argv[1]),content_type_dict[set_content_type_int])

	for array_dict in items_array_dict:

		listitem=xbmcgui.ListItem(label=array_dict[0],iconImage='DefaultFolder.png',thumbnailImage=array_dict[2],path=array_dict[1])

		infolabels_dict={'Title':array_dict[0]}
		infolabels_dict.update(array_dict[4])

		params_dict={'Title':array_dict[0],'Url':array_dict[1],'Img':array_dict[2]}
		params_dict.update(array_dict[5])

		listitem.setInfo(type=item_type_dict[set_items_type_int],infoLabels=infolabels_dict)
		listitem.setProperty('fanart_image',array_dict[3])

		if(set_params_dict == True):url=sys.argv[0] +'?'+ urllib.quote_plus(str(params_dict))
		if(set_params_dict == False):url=array_dict[1]

		if(Is_playable_bool == True):listitem.setProperty('IsPlayable','true')
		if(Is_playable_bool == False):listitem.setProperty('IsPlayable','false')

		xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=listitem,isFolder=is_folder_bool,totalItems=len(items_array_dict))

	xbmcplugin.endOfDirectory(handle=int(sys.argv[1]),succeeded=True,updateListing=False,cacheToDisc=True)

def get_regex_search(regex,content):
	return re.compile(regex,re.DOTALL).search(content)

def get_regex_findall(regex,content):
	return re.compile(regex,re.DOTALL).findall(content)

def get_resolved_url(url):
	source = urlresolver.HostedMediaFile(url=url)
	if source.valid_url():return source.resolve()
	else:return ''

def get_xbmc_player(title='',url='',img=''):

	listitem = xbmcgui.ListItem(label=title,iconImage=img,thumbnailImage=img)
	listitem.setInfo(type='video',infoLabels={'Title':title})
	listitem.setProperty('IsPlayable','true')

	player_.play(item=url,listitem=listitem)
	sys.exit(0)

def get_params_dict():
	argv = urllib.unquote_plus(sys.argv[2][1:])
	if argv.startswith('{') and argv.endswith('}'):return eval(argv)
	else:return {}
get_params_ = get_params_dict()

if get_params_ == {}:

	items_array_dict=[]
	items_array_dict.append(['Filme','https://hdstreamfilme.com/index.php?do=lastnews','','',{},{'Run':'2'}])
	items_array_dict.append(['Beliebte Filme','https://hdstreamfilme.com/beliebte-filme/','','',{},{'Run':'2'}])
	items_array_dict.append(['Animation','https://hdstreamfilme.com/animation/','','',{},{'Run':'2'}])
	items_array_dict.append(['Genres & Jahr & Co',BASE_URL,'','',{},{'Run':'1'}])
	items_array_dict.append([get_color_text('lime','Search'),'','','',{},{'Run':'5'}])
	add_items(items_array_dict, set_items_type_int=1, set_content_type_int=0, set_params_dict=True, is_folder_bool=True, Is_playable_bool=False)

elif get_params_.get('Run') == '1':

	url = get_params_.get('Url')
	content = get_cf_url(url,stream=False,timeout=30,allow_redirects=True,scraper_delay=0,headers_dict={}).content

	content = get_regex_search('<header class="header"[\s\S]*?<\/header>',content)
	if content:

		double_check=[]
		items_array_dict=[]
		for url,title in get_regex_findall('<li><a href="(\/.*?\/)">(.*?)<\/a><\/li>',content.group(0)):

			if not url in double_check:
				items_array_dict.append([title,BASE_URL + url,'','',{},{'Run':'2'}])
				double_check.append(url)

		add_items(items_array_dict, set_items_type_int=1, set_content_type_int=0, set_params_dict=True, is_folder_bool=True, Is_playable_bool=False)

elif get_params_.get('Run') == '2':

	url = get_params_.get('Url')
	content = get_cf_url(url,stream=False,timeout=30,allow_redirects=True,scraper_delay=0,headers_dict={}).content

	next_page_url = get_regex_search('<span class="pnext"><a href="(.*?)">',content)

	items_array_dict=[]
	for url,img,title in get_regex_findall('<a class="short-poster img-box with-mask" href="(.*?)".*?[\s\S]<img src="(.*?)".*?[\s\S]alt="(.*?)"',content):
		items_array_dict.append([title,url,BASE_URL + img,'',{},{'Run':'3'}])

	if next_page_url:
		color_text = get_color_text('lime','Next >>')
		items_array_dict.append([color_text,next_page_url.group(1),'','',{},{'Run':'2'}])
	add_items(items_array_dict, set_items_type_int=1, set_content_type_int=0, set_params_dict=True, is_folder_bool=True, Is_playable_bool=False)

elif get_params_.get('Run') == '3':

	title = get_params_.get('Title')
	url = get_params_.get('Url')
	img = get_params_.get('Img')

	content = get_cf_url(url,stream=False,timeout=30,allow_redirects=True,scraper_delay=0,headers_dict={}).content

	check=[]
	items_array_dict=[]
	for url in get_regex_findall('<div class="(?:fplay tabs-b video-box|fplay tabs-b video-box visible)">[\s\S]*?src="(http.*?)"',content):
		if (( not 'youtube' in url ) and ( not url in check )):
			check.append(url)
			items_array_dict.append([get_color_text('lime',title +' | '+ urlparse(url).netloc),url,img,'',{},{'Run':'4'}])
	add_items(items_array_dict, set_items_type_int=1, set_content_type_int=0, set_params_dict=True, is_folder_bool=True, Is_playable_bool=False)

elif get_params_.get('Run') == '4':

	title = get_params_.get('Title')
	url = get_params_.get('Url')
	img = get_params_.get('Img')

	resolved_url = get_resolved_url(url)
	if resolved_url:

		if player_.isPlaying(): 
			endtime = time.time() + 5
			while player_.isPlaying() and time.time() < endtime:player_.stop()

		host = urlparse(url).scheme + '://' + urlparse(url).netloc

		if 'verystream.com' in resolved_url:

			headers_dict_ = {
				'Origin':host,
				'User-Agent':resolved_url.split('|')[1],
				'Referer':url}

			r = get_cf_url(resolved_url.split('|')[0],timeout=30,allow_redirects=False,headers_dict=headers_dict_)
			if r.status_code >= 300 and r.status_code <= 400:resolved_url = r.headers['Location']
			r.close()

		resolved_url = resolved_url + '&Origin=' + host
		get_xbmc_player(title,resolved_url,img)

elif get_params_.get('Run') == '5':

	search_text = get_search_keyboard()
	new_search_url = BASE_URL + '/?do=search&mode=advanced&subaction=search&story=%s' % (search_text)
	content = get_cf_url(new_search_url,stream=False,timeout=30,allow_redirects=True,scraper_delay=0,headers_dict={}).content

	items_array_dict=[]
	for url,img,title in get_regex_findall('<a class="sres-wrap clearfix" href="(.*?)"[\s\S]*?><img src="(.*?)"[\s\S]*?alt="(.*?)"',content):
		items_array_dict.append([title,url,BASE_URL + img,'',{},{'Run':'3'}])
	add_items(items_array_dict, set_items_type_int=1, set_content_type_int=0, set_params_dict=True, is_folder_bool=True, Is_playable_bool=False)