import xbmc,xbmcgui,os,sys,shutil

temp_path       = xbmc.translatePath('special://temp')
packages_path   = xbmc.translatePath('special://home/addons/packages')

def getDirectorySize(directory):
     dir_size = 0
     for (path, dirs, files) in os.walk(directory):
         for file in files:

             filename = os.path.join(path, file)
             dir_size = os.path.getsize(filename)

     return int(dir_size)
	 
i = xbmcgui.Dialog().yesno('Kodi TP Cleaner','Temp       = ' + str(getDirectorySize(temp_path)/1024/1024) + 'MB','Packages = ' + str(getDirectorySize(packages_path)/1024/1024) + 'MB','','','Clean')

if i == 0:
     sys.exit()		
if os.path.exists(temp_path ) == True:
     shutil.rmtree(temp_path , ignore_errors=True)	  
if os.path.exists(packages_path ) == True:
     shutil.rmtree(packages_path , ignore_errors=True)

xbmcgui.Dialog().ok('Kodi TP Cleaner','Temp       = ' + str(getDirectorySize(temp_path)/1024/1024) + 'MB','Packages = ' + str(getDirectorySize(packages_path)/1024/1024) + 'MB')

